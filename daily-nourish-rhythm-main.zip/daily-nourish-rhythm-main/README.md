# Daily Nourish Rhythm

Design a modern, premium and visually attractive nutrition and diet tracking website called NutriTrack.

Typography:

Use Poppins for headings.

Use Inter for body text and descriptions.

Use clean font weights and consistent typography hierarchy.

Color palette:

Primary: Fresh Green (#22C55E)

Secondary: Soft Mint (#DCFCE7)

Background: Off White (#F8FAF7)

Text: Dark Charcoal (#1F2937)

Design style:

Modern health-tech dashboard.

Minimal, clean and responsive UI.

Rounded cards with subtle shadows.

Beautiful icons and charts.

Professional sidebar navigation.

Pages and features:

Home Dashboard

Daily Calorie Tracker

Food & Nutrition Details

Meal Planner

Water Intake Tracker

BMI Calculator

Weekly Nutrition Reports

Use React and Tailwind CSS. Do not use any database or backend. Use JavaScript arrays and localStorage for data storage. Make all buttons and interactions functional.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://daily-nourish-rhythm.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/145556ce-850a-5ecd-904e-bfd2cb705136).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
