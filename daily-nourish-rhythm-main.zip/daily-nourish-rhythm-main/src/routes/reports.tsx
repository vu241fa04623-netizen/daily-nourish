import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { ChevronLeft, ChevronRight, Download, Printer, Flame, Beef, Droplets, CalendarCheck, TrendingUp, TrendingDown, CheckCircle2, AlertCircle } from "lucide-react";
import { toast } from "sonner";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PageHeader, StatCard, chartTooltipStyle } from "@/components/nutri-ui";
import { useNutri } from "@/lib/store";
import { addDays, parseKey, sumEntries, todayKey } from "@/lib/nutrition";

export const Route = createFileRoute("/reports")({
  head: () => ({
    meta: [
      { title: "Weekly Nutrition Reports — NutriTrack" },
      { name: "description", content: "Weekly charts and insights for calories, macros and hydration." },
      { property: "og:title", content: "Weekly Nutrition Reports — NutriTrack" },
      { property: "og:description", content: "Weekly charts and insights for calories, macros and hydration." },
    ],
  }),
  component: ReportsPage,
});

function ReportsPage() {
  const s = useNutri();
  const today = todayKey();
  const [start, setStart] = useState(() => addDays(today, -6));
  const end = addDays(start, 6);
  const isCurrent = start >= addDays(today, -6);
  const { profile } = s;

  const days = Array.from({ length: 7 }, (_, i) => {
    const key = addDays(start, i);
    const t = sumEntries(s.logs[key] ?? []);
    return {
      key,
      day: parseKey(key).toLocaleDateString(undefined, { weekday: "short" }),
      calories: Math.round(t.calories),
      protein: Math.round(t.protein),
      carbs: Math.round(t.carbs),
      fat: Math.round(t.fat),
      water: (s.water[key] ?? []).reduce((a, w) => a + w.ml, 0),
      logged: (s.logs[key] ?? []).length > 0,
      future: key > today,
    };
  });

  const logged = days.filter((d) => d.logged);
  const n = logged.length || 1;
  const avg = (k: "calories" | "protein" | "carbs" | "fat" | "water") => Math.round(logged.reduce((a, d) => a + d[k], 0) / n);
  const waterDays = days.filter((d) => !d.future);
  const avgWater = Math.round(waterDays.reduce((a, d) => a + d.water, 0) / (waterDays.length || 1));
  const onTarget = logged.filter((d) => Math.abs(d.calories - profile.calorieGoal) <= profile.calorieGoal * 0.1).length;

  const totalP = logged.reduce((a, d) => a + d.protein * 4, 0);
  const totalC = logged.reduce((a, d) => a + d.carbs * 4, 0);
  const totalF = logged.reduce((a, d) => a + d.fat * 9, 0);
  const macroTotal = totalP + totalC + totalF;
  const pie = [
    { name: "Protein", value: totalP, color: "var(--protein)" },
    { name: "Carbs", value: totalC, color: "var(--carbs)" },
    { name: "Fat", value: totalF, color: "var(--fat)" },
  ];

  const prevDays = Array.from({ length: 7 }, (_, i) => sumEntries(s.logs[addDays(start, i - 7)] ?? []).calories);
  const prevLogged = prevDays.filter((c) => c > 0);
  const prevAvg = prevLogged.length ? prevLogged.reduce((a, c) => a + c, 0) / prevLogged.length : 0;
  const change = prevAvg ? Math.round(((avg("calories") - prevAvg) / prevAvg) * 100) : null;

  const insights: { good: boolean; text: string }[] = [];
  if (logged.length) {
    insights.push(
      avg("protein") >= profile.proteinGoal * 0.9
        ? { good: true, text: `Protein intake is strong at ${avg("protein")} g/day on average.` }
        : { good: false, text: `Protein averages ${avg("protein")} g/day — aim for ${profile.proteinGoal} g with lean meats, tofu or yogurt.` },
    );
    insights.push(
      onTarget >= Math.ceil(logged.length / 2)
        ? { good: true, text: `You hit your calorie target on ${onTarget} of ${logged.length} logged days.` }
        : { good: false, text: `Only ${onTarget} of ${logged.length} days were within 10% of your calorie goal.` },
    );
    insights.push(
      avgWater >= profile.waterGoal
        ? { good: true, text: `Excellent hydration — ${(avgWater / 1000).toFixed(1)} L per day on average.` }
        : { good: false, text: `Hydration averaged ${(avgWater / 1000).toFixed(1)} L — try adding one more bottle per day.` },
    );
    if (macroTotal && totalF / macroTotal > 0.35)
      insights.push({ good: false, text: "Fat makes up over 35% of calories. Swap some fried foods for grilled options." });
  }

  const exportCsv = () => {
    const header = "Date,Calories,Protein (g),Carbs (g),Fat (g),Water (ml)";
    const rows = days.map((d) => [d.key, d.calories, d.protein, d.carbs, d.fat, d.water].join(","));
    const blob = new Blob([[header, ...rows].join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `nutritrack-report-${start}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Report downloaded");
  };

  const fmt = (k: string) => parseKey(k).toLocaleDateString(undefined, { month: "short", day: "numeric" });

  return (
    <div>
      <PageHeader
        title="Weekly Reports"
        description="Trends, averages and insights for any 7 days."
        actions={
          <>
            <div className="flex items-center gap-1 rounded-xl border bg-card p-1 shadow-soft">
              <Button size="icon" variant="ghost" className="size-8" onClick={() => setStart(addDays(start, -7))} aria-label="Previous week">
                <ChevronLeft />
              </Button>
              <span className="min-w-36 text-center text-sm font-semibold">
                {fmt(start)} – {fmt(end)}
              </span>
              <Button size="icon" variant="ghost" className="size-8" disabled={isCurrent} onClick={() => setStart(addDays(start, 7))} aria-label="Next week">
                <ChevronRight />
              </Button>
            </div>
            <Button variant="outline" onClick={() => window.print()}>
              <Printer /> Print
            </Button>
            <Button onClick={exportCsv}>
              <Download /> Export CSV
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          icon={Flame}
          label="Avg. calories"
          value={avg("calories")}
          unit="kcal"
          hint={
            change === null ? (
              "No data for last week"
            ) : (
              <span className="inline-flex items-center gap-1">
                {change >= 0 ? <TrendingUp className="size-3" /> : <TrendingDown className="size-3" />}
                {Math.abs(change)}% vs last week
              </span>
            )
          }
        />
        <StatCard icon={Beef} tone="protein" label="Avg. protein" value={avg("protein")} unit="g" hint={`Goal ${profile.proteinGoal} g`} />
        <StatCard icon={Droplets} tone="water" label="Avg. water" value={(avgWater / 1000).toFixed(1)} unit="L" hint={`Goal ${profile.waterGoal / 1000} L`} />
        <StatCard icon={CalendarCheck} tone="carbs" label="Days on target" value={`${onTarget}/${logged.length}`} hint="Within ±10% of goal" />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="p-6 lg:col-span-2">
          <h2 className="font-display text-lg font-semibold">Daily calories</h2>
          <p className="text-sm text-muted-foreground">Dashed line shows your {profile.calorieGoal} kcal goal</p>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={days} margin={{ left: -12, right: 8, top: 10 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
                <XAxis dataKey="day" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
                <YAxis tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
                <Tooltip {...chartTooltipStyle} cursor={{ fill: "var(--secondary)" }} />
                <ReferenceLine y={profile.calorieGoal} stroke="var(--muted-foreground)" strokeDasharray="5 5" />
                <Bar dataKey="calories" name="Calories" radius={[8, 8, 0, 0]} maxBarSize={40}>
                  {days.map((d) => (
                    <Cell key={d.key} fill={d.calories > profile.calorieGoal * 1.1 ? "var(--protein)" : "var(--primary)"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="font-display text-lg font-semibold">Macro distribution</h2>
          <p className="text-sm text-muted-foreground">Share of calories this week</p>
          <div className="relative mt-2 h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={macroTotal ? pie : [{ name: "None", value: 1, color: "var(--muted)" }]} dataKey="value" innerRadius={55} outerRadius={80} paddingAngle={macroTotal ? 3 : 0} stroke="none">
                  {(macroTotal ? pie : [{ color: "var(--muted)" }]).map((p, i) => (
                    <Cell key={i} fill={p.color} />
                  ))}
                </Pie>
                {macroTotal > 0 && <Tooltip {...chartTooltipStyle} formatter={(v: number) => `${Math.round((v / macroTotal) * 100)}%`} />}
              </PieChart>
            </ResponsiveContainer>
            <div className="pointer-events-none absolute inset-0 grid place-items-center text-center">
              <div>
                <p className="font-display text-xl font-semibold">{logged.length}</p>
                <p className="text-xs text-muted-foreground">days logged</p>
              </div>
            </div>
          </div>
          <div className="mt-2 space-y-2">
            {pie.map((p) => (
              <div key={p.name} className="flex items-center gap-2 text-sm">
                <span className="size-2.5 rounded-full" style={{ background: p.color }} />
                <span className="flex-1">{p.name}</span>
                <span className="font-semibold">{macroTotal ? Math.round((p.value / macroTotal) * 100) : 0}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Card className="p-6">
          <h2 className="font-display text-lg font-semibold">Macros per day</h2>
          <div className="mt-4 h-60">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={days} margin={{ left: -12, right: 8, top: 10 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
                <XAxis dataKey="day" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
                <YAxis tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" unit="g" />
                <Tooltip {...chartTooltipStyle} cursor={{ fill: "var(--muted)" }} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="protein" name="Protein" stackId="m" fill="var(--protein)" maxBarSize={36} />
                <Bar dataKey="carbs" name="Carbs" stackId="m" fill="var(--carbs)" maxBarSize={36} />
                <Bar dataKey="fat" name="Fat" stackId="m" fill="var(--fat)" radius={[6, 6, 0, 0]} maxBarSize={36} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="font-display text-lg font-semibold">Hydration</h2>
          <div className="mt-4 h-60">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={days} margin={{ left: -6, right: 8, top: 10 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
                <XAxis dataKey="day" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
                <YAxis tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
                <Tooltip {...chartTooltipStyle} formatter={(v: number) => [`${v} ml`, "Water"]} />
                <ReferenceLine y={profile.waterGoal} stroke="var(--water)" strokeDasharray="5 5" />
                <Line type="monotone" dataKey="water" stroke="var(--water)" strokeWidth={3} dot={{ r: 4, fill: "var(--water)" }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <Card className="mt-6 p-6">
        <h2 className="font-display text-lg font-semibold">Insights</h2>
        {insights.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">No meals logged this week yet — insights will appear once you start tracking.</p>
        ) : (
          <div className="mt-4 grid gap-3 md:grid-cols-2">
            {insights.map((i) => (
              <div key={i.text} className={i.good ? "flex gap-3 rounded-xl bg-secondary p-4" : "flex gap-3 rounded-xl bg-warning-soft p-4"}>
                {i.good ? <CheckCircle2 className="size-5 shrink-0 text-primary" /> : <AlertCircle className="size-5 shrink-0 text-warning" />}
                <p className="text-sm">{i.text}</p>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
