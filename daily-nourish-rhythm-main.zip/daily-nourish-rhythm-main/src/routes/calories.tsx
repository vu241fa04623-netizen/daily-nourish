import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronLeft, ChevronRight, Flame, Plus, Minus, Trash2, Target, Utensils, CalendarCheck, Eraser } from "lucide-react";
import { toast } from "sonner";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FoodPickerDialog } from "@/components/food-picker-dialog";
import { MacroBar, PageHeader, ProgressRing, StatCard } from "@/components/nutri-ui";
import { actions, useNutri } from "@/lib/store";
import { addDays, MEALS, parseKey, sumEntries, todayKey } from "@/lib/nutrition";

export const Route = createFileRoute("/calories")({
  head: () => ({
    meta: [
      { title: "Daily Calorie Tracker — NutriTrack" },
      { name: "description", content: "Log meals, adjust servings and track calories and macros day by day." },
      { property: "og:title", content: "Daily Calorie Tracker — NutriTrack" },
      { property: "og:description", content: "Log meals, adjust servings and track calories and macros day by day." },
    ],
  }),
  component: CaloriesPage,
});

function CaloriesPage() {
  const s = useNutri();
  const today = todayKey();
  const [day, setDay] = useState(today);
  const [editingGoal, setEditingGoal] = useState(false);
  const [goalInput, setGoalInput] = useState(String(s.profile.calorieGoal));
  const entries = s.logs[day] ?? [];
  const totals = sumEntries(entries);
  const goal = s.profile.calorieGoal;
  const remaining = goal - totals.calories;
  const isToday = day === today;

  const label = isToday
    ? "Today"
    : day === addDays(today, -1)
      ? "Yesterday"
      : parseKey(day).toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" });

  const saveGoal = () => {
    const v = Number(goalInput);
    if (!v || v < 800 || v > 6000) { toast.error("Goal should be between 800 and 6000 kcal"); return; }
    actions.updateProfile({ calorieGoal: v });
    setEditingGoal(false);
    toast.success("Calorie goal updated");
  };

  return (
    <div>
      <PageHeader
        title="Daily Calorie Tracker"
        description="Log what you eat and stay on top of your daily energy balance."
        actions={
          <div className="flex items-center gap-1 rounded-xl border bg-card p-1 shadow-soft">
            <Button size="icon" variant="ghost" className="size-8" onClick={() => setDay(addDays(day, -1))} aria-label="Previous day">
              <ChevronLeft />
            </Button>
            <span className="min-w-36 text-center text-sm font-semibold">{label}</span>
            <Button size="icon" variant="ghost" className="size-8" disabled={isToday} onClick={() => setDay(addDays(day, 1))} aria-label="Next day">
              <ChevronRight />
            </Button>
            {!isToday && (
              <Button size="sm" variant="soft" onClick={() => setDay(today)}>
                <CalendarCheck /> Today
              </Button>
            )}
          </div>
        }
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <div className="grid grid-cols-3 gap-4">
            <StatCard icon={Target} label="Goal" value={goal} unit="kcal" />
            <StatCard icon={Utensils} tone="protein" label="Food" value={Math.round(totals.calories)} unit="kcal" />
            <StatCard icon={Flame} tone={remaining < 0 ? "protein" : "primary"} label={remaining < 0 ? "Over" : "Remaining"} value={Math.abs(Math.round(remaining))} unit="kcal" />
          </div>

          {MEALS.map((m) => {
            const items = entries.filter((e) => e.meal === m.id);
            const mt = sumEntries(items);
            return (
              <Card key={m.id} className="overflow-hidden animate-fade-up">
                <div className="flex items-center justify-between gap-3 border-b bg-gradient-mint px-5 py-4">
                  <div className="flex items-center gap-3">
                    <span className="grid size-10 place-items-center rounded-xl bg-card text-xl shadow-soft">{m.emoji}</span>
                    <div>
                      <h2 className="font-display font-semibold">{m.label}</h2>
                      <p className="text-xs text-muted-foreground">
                        {Math.round(mt.calories)} kcal · P {Math.round(mt.protein)}g · C {Math.round(mt.carbs)}g · F {Math.round(mt.fat)}g
                      </p>
                    </div>
                  </div>
                  <FoodPickerDialog
                    defaultMeal={m.id}
                    day={day}
                    trigger={
                      <Button size="sm">
                        <Plus /> Add food
                      </Button>
                    }
                  />
                </div>
                {items.length === 0 ? (
                  <p className="px-5 py-6 text-center text-sm text-muted-foreground">No foods logged for {m.label.toLowerCase()} yet.</p>
                ) : (
                  <ul className="divide-y">
                    {items.map((e) => (
                      <li key={e.id} className="flex items-center gap-3 px-5 py-3">
                        <span className="text-2xl">{e.emoji}</span>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-medium">{e.name}</p>
                          <p className="text-xs text-muted-foreground">
                            P {Math.round(e.protein * e.servings)}g · C {Math.round(e.carbs * e.servings)}g · F {Math.round(e.fat * e.servings)}g
                          </p>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button size="icon" variant="outline" className="size-7" aria-label="Decrease servings" onClick={() => e.servings > 0.5 && actions.updateServings(day, e.id, e.servings - 0.5)}>
                            <Minus />
                          </Button>
                          <span className="w-9 text-center text-sm font-medium">{e.servings}×</span>
                          <Button size="icon" variant="outline" className="size-7" aria-label="Increase servings" onClick={() => actions.updateServings(day, e.id, e.servings + 0.5)}>
                            <Plus />
                          </Button>
                        </div>
                        <span className="w-16 text-right text-sm font-semibold">{Math.round(e.calories * e.servings)} kcal</span>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="size-8 text-muted-foreground hover:text-destructive"
                          aria-label={`Remove ${e.name}`}
                          onClick={() => {
                            actions.removeEntry(day, e.id);
                            toast(`${e.name} removed`, {
                              action: { label: "Undo", onClick: () => actions.addFood({ id: e.foodId ?? e.id, name: e.name, emoji: e.emoji, calories: e.calories, protein: e.protein, carbs: e.carbs, fat: e.fat, category: "Snacks", serving: "", fiber: 0, sugar: 0, sodium: 0, description: "", vitamins: [] }, e.meal, e.servings, day) },
                            });
                          }}
                        >
                          <Trash2 />
                        </Button>
                      </li>
                    ))}
                  </ul>
                )}
              </Card>
            );
          })}
        </div>

        <div className="space-y-6">
          <Card className="flex flex-col items-center p-6 lg:sticky lg:top-24">
            <h2 className="self-start font-display text-lg font-semibold">Daily summary</h2>
            <div className="my-5">
              <ProgressRing value={totals.calories} max={goal} colorVar={remaining < 0 ? "--destructive" : "--primary"} trackVar="--secondary">
                <div>
                  <p className="font-display text-3xl font-semibold">{Math.round((totals.calories / goal) * 100)}%</p>
                  <p className="text-xs text-muted-foreground">of daily goal</p>
                </div>
              </ProgressRing>
            </div>
            <div className="w-full space-y-4">
              <MacroBar label="Protein" value={totals.protein} goal={s.profile.proteinGoal} tone="protein" />
              <MacroBar label="Carbs" value={totals.carbs} goal={s.profile.carbsGoal} tone="carbs" />
              <MacroBar label="Fat" value={totals.fat} goal={s.profile.fatGoal} tone="fat" />
            </div>

            <div className="mt-6 w-full rounded-xl bg-muted p-4">
              <p className="text-sm font-medium">Daily calorie goal</p>
              {editingGoal ? (
                <div className="mt-2 flex gap-2">
                  <Input type="number" value={goalInput} onChange={(e) => setGoalInput(e.target.value)} className="h-9 bg-card" />
                  <Button size="sm" onClick={saveGoal}>Save</Button>
                </div>
              ) : (
                <div className="mt-1 flex items-center justify-between">
                  <span className="font-display text-xl font-semibold">{goal} kcal</span>
                  <Button size="sm" variant="outline" onClick={() => { setGoalInput(String(goal)); setEditingGoal(true); }}>
                    Edit
                  </Button>
                </div>
              )}
            </div>

            {entries.length > 0 && (
              <Button
                variant="ghost"
                className="mt-3 w-full text-muted-foreground hover:text-destructive"
                onClick={() => {
                  if (window.confirm(`Clear all foods logged for ${label.toLowerCase()}?`)) {
                    actions.clearDay(day);
                    toast.success("Day cleared");
                  }
                }}
              >
                <Eraser /> Clear this day
              </Button>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
