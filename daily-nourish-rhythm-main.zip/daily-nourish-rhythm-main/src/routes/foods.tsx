import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { Search, Heart, Plus, Minus, Leaf, SlidersHorizontal } from "lucide-react";
import { toast } from "sonner";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EmptyState, PageHeader, chartTooltipStyle } from "@/components/nutri-ui";
import { cn } from "@/lib/utils";
import { FOOD_CATEGORIES, type Food } from "@/data/foods";
import { MEALS, type MealType } from "@/lib/nutrition";
import { actions, allFoods, useNutri } from "@/lib/store";

export const Route = createFileRoute("/foods")({
  head: () => ({
    meta: [
      { title: "Food & Nutrition Details — NutriTrack" },
      { name: "description", content: "Browse foods with full nutrition facts, macro breakdowns and vitamins." },
      { property: "og:title", content: "Food & Nutrition Details — NutriTrack" },
      { property: "og:description", content: "Browse foods with full nutrition facts, macro breakdowns and vitamins." },
    ],
  }),
  component: FoodsPage,
});

type SortKey = "name" | "calories" | "protein" | "fiber";

function FoodsPage() {
  const s = useNutri();
  const foods = allFoods(s);
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<string>("All");
  const [favOnly, setFavOnly] = useState(false);
  const [sort, setSort] = useState<SortKey>("name");
  const [selected, setSelected] = useState<Food | null>(null);

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return foods
      .filter((f) => (cat === "All" ? true : f.category === cat))
      .filter((f) => (favOnly ? s.favorites.includes(f.id) : true))
      .filter((f) => !q || f.name.toLowerCase().includes(q))
      .sort((a, b) => (sort === "name" ? a.name.localeCompare(b.name) : b[sort] - a[sort]));
  }, [foods, query, cat, favOnly, sort, s.favorites]);

  return (
    <div>
      <PageHeader title="Food & Nutrition" description="Explore nutrition facts for everyday foods and add them to your log." />

      <Card className="mb-6 p-4">
        <div className="flex flex-col gap-3 md:flex-row md:items-center">
          <div className="relative flex-1">
            <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search foods…" className="h-10 rounded-xl pl-9" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          <div className="flex gap-2">
            <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
              <SelectTrigger className="h-10 w-44 rounded-xl">
                <SlidersHorizontal className="size-4 text-muted-foreground" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Sort: Name</SelectItem>
                <SelectItem value="calories">Sort: Calories</SelectItem>
                <SelectItem value="protein">Sort: Protein</SelectItem>
                <SelectItem value="fiber">Sort: Fiber</SelectItem>
              </SelectContent>
            </Select>
            <Button variant={favOnly ? "default" : "outline"} className="h-10" onClick={() => setFavOnly((v) => !v)}>
              <Heart className={cn(favOnly && "fill-current")} /> Favorites
            </Button>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {["All", ...FOOD_CATEGORIES].map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={cn(
                "rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors",
                cat === c ? "border-primary bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-secondary hover:text-secondary-foreground",
              )}
            >
              {c}
            </button>
          ))}
        </div>
      </Card>

      {list.length === 0 ? (
        <EmptyState icon={Leaf} title="No foods match" text="Try another search term or category." />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {list.map((f) => {
            const fav = s.favorites.includes(f.id);
            return (
              <Card
                key={f.id}
                role="button"
                tabIndex={0}
                onClick={() => setSelected(f)}
                onKeyDown={(e) => e.key === "Enter" && setSelected(f)}
                className="group cursor-pointer p-5 transition-all hover:-translate-y-0.5 hover:border-primary/40 animate-fade-up"
              >
                <div className="flex items-start justify-between">
                  <span className="grid size-14 place-items-center rounded-2xl bg-secondary text-3xl transition-transform group-hover:scale-105">{f.emoji}</span>
                  <button
                    aria-label={fav ? "Remove from favorites" : "Add to favorites"}
                    onClick={(e) => {
                      e.stopPropagation();
                      actions.toggleFavorite(f.id);
                    }}
                    className="rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-destructive"
                  >
                    <Heart className={cn("size-5", fav && "fill-destructive text-destructive")} />
                  </button>
                </div>
                <h3 className="mt-4 font-display font-semibold">{f.name}</h3>
                <p className="text-xs text-muted-foreground">{f.serving}</p>
                <div className="mt-3 flex items-baseline gap-1">
                  <span className="font-display text-2xl font-semibold">{f.calories}</span>
                  <span className="text-xs text-muted-foreground">kcal</span>
                  <Badge variant="secondary" className="ml-auto rounded-full bg-muted font-normal text-muted-foreground">{f.category}</Badge>
                </div>
                <div className="mt-3 grid grid-cols-3 gap-1.5 text-center text-xs">
                  <span className="rounded-lg bg-protein-soft py-1.5 font-medium text-protein">P {f.protein}g</span>
                  <span className="rounded-lg bg-carbs-soft py-1.5 font-medium text-carbs">C {f.carbs}g</span>
                  <span className="rounded-lg bg-fat-soft py-1.5 font-medium text-warning">F {f.fat}g</span>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <FoodDetailSheet food={selected} onClose={() => setSelected(null)} favorite={!!selected && s.favorites.includes(selected.id)} />
    </div>
  );
}

function FoodDetailSheet({ food, onClose, favorite }: { food: Food | null; onClose: () => void; favorite: boolean }) {
  const [meal, setMeal] = useState<MealType>("lunch");
  const [servings, setServings] = useState(1);

  const pie = food
    ? [
        { name: "Protein", value: Math.round(food.protein * 4), color: "var(--protein)" },
        { name: "Carbs", value: Math.round(food.carbs * 4), color: "var(--carbs)" },
        { name: "Fat", value: Math.round(food.fat * 9), color: "var(--fat)" },
      ]
    : [];
  const pieTotal = pie.reduce((a, p) => a + p.value, 0);

  return (
    <Sheet
      open={!!food}
      onOpenChange={(o) => {
        if (!o) {
          onClose();
          setServings(1);
        }
      }}
    >
      <SheetContent className="w-full overflow-y-auto sm:max-w-md">
        {food && (
          <>
            <SheetHeader className="text-left">
              <span className="grid size-16 place-items-center rounded-2xl bg-secondary text-4xl">{food.emoji}</span>
              <SheetTitle className="font-display text-xl">{food.name}</SheetTitle>
              <SheetDescription>{food.description}</SheetDescription>
            </SheetHeader>

            <div className="mt-5 flex items-center gap-2">
              <Badge variant="secondary" className="rounded-full">{food.category}</Badge>
              <span className="text-sm text-muted-foreground">Serving: {food.serving}</span>
              <Button size="sm" variant="ghost" className="ml-auto" onClick={() => actions.toggleFavorite(food.id)}>
                <Heart className={cn(favorite && "fill-destructive text-destructive")} /> {favorite ? "Saved" : "Save"}
              </Button>
            </div>

            <div className="mt-5 flex items-center gap-4 rounded-2xl border p-4">
              <div className="relative h-32 w-32 shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={pieTotal ? pie : [{ name: "None", value: 1, color: "var(--muted)" }]} dataKey="value" innerRadius={42} outerRadius={60} paddingAngle={pieTotal ? 3 : 0} stroke="none">
                      {(pieTotal ? pie : [{ color: "var(--muted)" }]).map((p, i) => (
                        <Cell key={i} fill={p.color} />
                      ))}
                    </Pie>
                    {pieTotal > 0 && <Tooltip {...chartTooltipStyle} formatter={(v: number) => `${v} kcal`} />}
                  </PieChart>
                </ResponsiveContainer>
                <div className="pointer-events-none absolute inset-0 grid place-items-center text-center">
                  <div>
                    <p className="font-display text-lg font-semibold leading-none">{food.calories}</p>
                    <p className="text-[10px] text-muted-foreground">kcal</p>
                  </div>
                </div>
              </div>
              <div className="flex-1 space-y-2 text-sm">
                {pie.map((p) => (
                  <div key={p.name} className="flex items-center gap-2">
                    <span className="size-2.5 rounded-full" style={{ background: p.color }} />
                    <span className="flex-1">{p.name}</span>
                    <span className="font-semibold">{pieTotal ? Math.round((p.value / pieTotal) * 100) : 0}%</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-5 rounded-2xl border p-4">
              <h3 className="font-display text-base font-semibold">Nutrition facts</h3>
              <p className="text-xs text-muted-foreground">Per {food.serving}</p>
              <dl className="mt-3 divide-y text-sm">
                {([
                  ["Calories", `${food.calories} kcal`],
                  ["Protein", `${food.protein} g`],
                  ["Carbohydrates", `${food.carbs} g`],
                  ["— Fiber", `${food.fiber} g`],
                  ["— Sugar", `${food.sugar} g`],
                  ["Fat", `${food.fat} g`],
                  ["Sodium", `${food.sodium} mg`],
                ] as [string, string][]).map(([k, v]) => (
                  <div key={k} className="flex justify-between py-2">
                    <dt className={cn(k.startsWith("—") ? "pl-3 text-muted-foreground" : "font-medium")}>{k.replace("— ", "")}</dt>
                    <dd className="font-semibold">{v}</dd>
                  </div>
                ))}
              </dl>
            </div>

            {food.vitamins.length > 0 && (
              <div className="mt-5">
                <h3 className="font-display text-sm font-semibold">Rich in</h3>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {food.vitamins.map((v) => (
                    <span key={v} className="rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground">{v}</span>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-6 space-y-3 rounded-2xl bg-muted p-4">
              <h3 className="font-display text-sm font-semibold">Add to today's log</h3>
              <div className="flex flex-wrap gap-1.5">
                {MEALS.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setMeal(m.id)}
                    className={cn(
                      "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                      meal === m.id ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:bg-secondary",
                    )}
                  >
                    {m.emoji} {m.label}
                  </button>
                ))}
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Button size="icon" variant="outline" className="size-8 bg-card" onClick={() => setServings((v) => Math.max(0.5, v - 0.5))}>
                    <Minus />
                  </Button>
                  <span className="w-12 text-center text-sm font-semibold">{servings}×</span>
                  <Button size="icon" variant="outline" className="size-8 bg-card" onClick={() => setServings((v) => Math.min(10, v + 0.5))}>
                    <Plus />
                  </Button>
                </div>
                <span className="text-sm font-semibold">{Math.round(food.calories * servings)} kcal</span>
              </div>
              <Button
                className="w-full"
                onClick={() => {
                  actions.addFood(food, meal, servings);
                  toast.success(`${food.name} added to ${MEALS.find((m) => m.id === meal)?.label}`);
                  onClose();
                  setServings(1);
                }}
              >
                <Plus /> Add to log
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
