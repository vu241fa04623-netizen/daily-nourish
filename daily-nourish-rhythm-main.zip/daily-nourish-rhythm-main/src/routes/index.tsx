import { createFileRoute, Link } from "@tanstack/react-router";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Flame, Droplets, Plus, Scale, Beef, Wheat, Utensils, ArrowRight, Target, Trophy } from "lucide-react";
import { toast } from "sonner";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FoodPickerDialog } from "@/components/food-picker-dialog";
import { MacroBar, ProgressRing, StatCard, EmptyState, chartTooltipStyle } from "@/components/nutri-ui";
import { actions, useNutri } from "@/lib/store";
import { addDays, bmiCategory, MEALS, parseKey, sumEntries, todayKey } from "@/lib/nutrition";
import bowl from "@/assets/healthy-bowl.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — NutriTrack" },
      { name: "description", content: "Your daily nutrition overview: calories, macros, water and BMI at a glance." },
      { property: "og:title", content: "Dashboard — NutriTrack" },
      { property: "og:description", content: "Your daily nutrition overview: calories, macros, water and BMI at a glance." },
    ],
  }),
  component: Dashboard,
});

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

function Dashboard() {
  const s = useNutri();
  const today = todayKey();
  const entries = s.logs[today] ?? [];
  const totals = sumEntries(entries);
  const { profile } = s;
  const remaining = profile.calorieGoal - totals.calories;
  const water = (s.water[today] ?? []).reduce((a, w) => a + w.ml, 0);
  const latestBmi = s.bmi[s.bmi.length - 1];

  const week = Array.from({ length: 7 }, (_, i) => {
    const key = addDays(today, i - 6);
    return {
      day: parseKey(key).toLocaleDateString(undefined, { weekday: "short" }),
      calories: Math.round(sumEntries(s.logs[key] ?? []).calories),
      goal: profile.calorieGoal,
    };
  });
  const streak = (() => {
    let n = 0;
    for (let i = 0; i < 365; i++) {
      if ((s.logs[addDays(today, -i)] ?? []).length > 0) n++;
      else break;
    }
    return n;
  })();

  return (
    <div className="space-y-6">
      {/* Banner */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-hero p-6 text-primary-foreground shadow-glow sm:p-8 animate-fade-up">
        <div className="relative z-10 max-w-xl">
          <p className="text-sm font-medium opacity-85">
            {new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}
          </p>
          <h1 className="mt-1 text-2xl font-semibold sm:text-3xl">
            {greeting()}, {profile.name} 👋
          </h1>
          <p className="mt-2 text-sm leading-relaxed opacity-90 sm:text-base">
            {remaining >= 0
              ? `You have ${Math.round(remaining)} kcal left today. Keep up the balanced eating!`
              : `You're ${Math.round(-remaining)} kcal over your goal today — a light dinner will balance it out.`}
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            <FoodPickerDialog
              trigger={
                <Button variant="hero">
                  <Plus /> Log food
                </Button>
              }
            />
            <Button
              variant="glass"
              onClick={() => {
                actions.addWater(250);
                toast.success("+250 ml water logged 💧");
              }}
            >
              <Droplets /> Add a glass
            </Button>
          </div>
        </div>
        <img
          src={bowl}
          alt="Healthy salmon poke bowl"
          width={1024}
          height={1024}
          className="pointer-events-none absolute -right-10 -bottom-16 hidden w-72 drop-shadow-2xl md:block lg:w-80"
        />
      </section>

      {/* Stats */}
      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon={Flame} label="Calories eaten" value={Math.round(totals.calories)} unit="kcal" hint={`Goal ${profile.calorieGoal} kcal`} />
        <StatCard icon={Droplets} tone="water" label="Water intake" value={(water / 1000).toFixed(2)} unit="L" hint={`${Math.round((water / profile.waterGoal) * 100)}% of ${profile.waterGoal / 1000} L`} />
        <StatCard
          icon={Scale}
          tone="carbs"
          label="Current BMI"
          value={latestBmi ? latestBmi.bmi : "—"}
          hint={latestBmi ? bmiCategory(latestBmi.bmi) : "Calculate your BMI"}
        />
        <StatCard icon={Trophy} tone="fat" label="Logging streak" value={streak} unit={streak === 1 ? "day" : "days"} hint="Consecutive days logged" />
      </section>

      <section className="grid gap-6 lg:grid-cols-3">
        {/* Calorie ring */}
        <Card className="flex flex-col items-center p-6">
          <div className="flex w-full items-center justify-between">
            <h2 className="font-display text-lg font-semibold">Today's calories</h2>
            <Link to="/calories" className="text-sm font-medium text-primary hover:underline">
              Details
            </Link>
          </div>
          <div className="my-5">
            <ProgressRing value={totals.calories} max={profile.calorieGoal} colorVar={remaining < 0 ? "--destructive" : "--primary"} trackVar="--secondary">
              <div>
                <p className="font-display text-3xl font-semibold">{Math.abs(Math.round(remaining))}</p>
                <p className="text-xs text-muted-foreground">{remaining >= 0 ? "kcal remaining" : "kcal over"}</p>
              </div>
            </ProgressRing>
          </div>
          <div className="grid w-full grid-cols-2 gap-3 text-center">
            <div className="rounded-xl bg-muted p-3">
              <p className="text-xs text-muted-foreground">Eaten</p>
              <p className="font-display font-semibold">{Math.round(totals.calories)}</p>
            </div>
            <div className="rounded-xl bg-muted p-3">
              <p className="text-xs text-muted-foreground">Goal</p>
              <p className="font-display font-semibold">{profile.calorieGoal}</p>
            </div>
          </div>
        </Card>

        {/* Macros */}
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold">Macronutrients</h2>
            <Target className="size-5 text-muted-foreground" />
          </div>
          <div className="mt-6 space-y-5">
            <MacroBar label="Protein" value={totals.protein} goal={profile.proteinGoal} tone="protein" />
            <MacroBar label="Carbs" value={totals.carbs} goal={profile.carbsGoal} tone="carbs" />
            <MacroBar label="Fat" value={totals.fat} goal={profile.fatGoal} tone="fat" />
          </div>
          <div className="mt-6 grid grid-cols-3 gap-2 text-center">
            {[
              { icon: Beef, label: "Protein", v: totals.protein * 4 },
              { icon: Wheat, label: "Carbs", v: totals.carbs * 4 },
              { icon: Flame, label: "Fat", v: totals.fat * 9 },
            ].map((m) => {
              const kcal = totals.protein * 4 + totals.carbs * 4 + totals.fat * 9;
              return (
                <div key={m.label} className="rounded-xl border p-2.5">
                  <m.icon className="mx-auto size-4 text-muted-foreground" />
                  <p className="mt-1 font-display text-sm font-semibold">{kcal ? Math.round((m.v / kcal) * 100) : 0}%</p>
                  <p className="text-[11px] text-muted-foreground">{m.label}</p>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Water */}
        <Card className="flex flex-col p-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold">Hydration</h2>
            <Link to="/water" className="text-sm font-medium text-primary hover:underline">
              Open
            </Link>
          </div>
          <div className="my-5 flex justify-center">
            <ProgressRing value={water} max={profile.waterGoal} size={150} stroke={12} colorVar="--water" trackVar="--water-soft">
              <div>
                <Droplets className="mx-auto size-5 text-water" />
                <p className="font-display text-2xl font-semibold">{water}</p>
                <p className="text-xs text-muted-foreground">of {profile.waterGoal} ml</p>
              </div>
            </ProgressRing>
          </div>
          <div className="mt-auto grid grid-cols-3 gap-2">
            {[150, 250, 500].map((ml) => (
              <Button
                key={ml}
                variant="water"
                size="sm"
                onClick={() => {
                  actions.addWater(ml);
                  toast.success(`+${ml} ml water logged 💧`);
                }}
              >
                +{ml}
              </Button>
            ))}
          </div>
        </Card>
      </section>

      <section className="grid gap-6 lg:grid-cols-5">
        <Card className="p-6 lg:col-span-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display text-lg font-semibold">Last 7 days</h2>
              <p className="text-sm text-muted-foreground">Calories consumed vs. goal</p>
            </div>
            <Button asChild variant="soft" size="sm">
              <Link to="/reports">
                Reports <ArrowRight />
              </Link>
            </Button>
          </div>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={week} margin={{ left: -16, right: 8, top: 10 }}>
                <defs>
                  <linearGradient id="calFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
                <XAxis dataKey="day" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
                <YAxis tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
                <Tooltip {...chartTooltipStyle} />
                <Area type="monotone" dataKey="goal" name="Goal" stroke="var(--muted-foreground)" strokeDasharray="5 5" fill="none" strokeWidth={1.5} />
                <Area type="monotone" dataKey="calories" name="Calories" stroke="var(--primary)" strokeWidth={2.5} fill="url(#calFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-6 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold">Today's meals</h2>
            <FoodPickerDialog
              trigger={
                <Button size="sm" variant="soft">
                  <Plus /> Add
                </Button>
              }
            />
          </div>
          <div className="mt-4 space-y-2.5">
            {entries.length === 0 ? (
              <EmptyState icon={Utensils} title="Nothing logged yet" text="Log your first meal to see it here." />
            ) : (
              MEALS.map((m) => {
                const items = entries.filter((e) => e.meal === m.id);
                const kcal = Math.round(sumEntries(items).calories);
                return (
                  <div key={m.id} className="flex items-center gap-3 rounded-xl border p-3">
                    <span className="grid size-10 place-items-center rounded-xl bg-secondary text-lg">{m.emoji}</span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold">{m.label}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {items.length ? items.map((i) => i.name).join(", ") : "Not logged yet"}
                      </p>
                    </div>
                    <span className="text-sm font-semibold">{kcal}</span>
                    <span className="text-xs text-muted-foreground">kcal</span>
                  </div>
                );
              })
            )}
          </div>
        </Card>
      </section>
    </div>
  );
}
