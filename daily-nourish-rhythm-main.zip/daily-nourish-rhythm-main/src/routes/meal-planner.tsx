import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, X, Sparkles, Copy, Eraser, ClipboardCheck, Flame } from "lucide-react";
import { toast } from "sonner";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FoodPickerDialog } from "@/components/food-picker-dialog";
import { MacroBar, PageHeader, ProgressRing } from "@/components/nutri-ui";
import { cn } from "@/lib/utils";
import { FOODS, type Food, type FoodCategory } from "@/data/foods";
import { MEALS, type MealType } from "@/lib/nutrition";
import { actions, allFoods, useNutri, type DayPlan } from "@/lib/store";

export const Route = createFileRoute("/meal-planner")({
  head: () => ({
    meta: [
      { title: "Meal Planner — NutriTrack" },
      { name: "description", content: "Plan balanced breakfasts, lunches, dinners and snacks for the whole week." },
      { property: "og:title", content: "Meal Planner — NutriTrack" },
      { property: "og:description", content: "Plan balanced breakfasts, lunches, dinners and snacks for the whole week." },
    ],
  }),
  component: MealPlannerPage,
});

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

function planTotals(plan: DayPlan | undefined, foods: Food[]) {
  const t = { calories: 0, protein: 0, carbs: 0, fat: 0 };
  if (!plan) return t;
  (Object.keys(plan) as MealType[]).forEach((m) =>
    plan[m].forEach((id) => {
      const f = foods.find((x) => x.id === id);
      if (f) {
        t.calories += f.calories;
        t.protein += f.protein;
        t.carbs += f.carbs;
        t.fat += f.fat;
      }
    }),
  );
  return t;
}

function pick(cats: FoodCategory[]) {
  const pool = FOODS.filter((f) => cats.includes(f.category));
  return pool[Math.floor(Math.random() * pool.length)]!.id;
}

function generatePlan(): DayPlan {
  const uniq = (ids: string[]) => Array.from(new Set(ids));
  return {
    breakfast: uniq([pick(["Grains", "Dairy"]), pick(["Fruits"]), pick(["Drinks", "Dairy"])]),
    lunch: uniq([pick(["Proteins"]), pick(["Grains"]), pick(["Vegetables"])]),
    dinner: uniq([pick(["Proteins"]), pick(["Vegetables"]), pick(["Vegetables", "Grains"])]),
    snack: uniq([pick(["Snacks", "Fruits"])]),
  };
}

function MealPlannerPage() {
  const s = useNutri();
  const foods = allFoods(s);
  const [day, setDay] = useState(() => (new Date().getDay() + 6) % 7);
  const plan = s.plan[String(day)];
  const totals = planTotals(plan, foods);
  const goal = s.profile.calorieGoal;

  return (
    <div>
      <PageHeader
        title="Meal Planner"
        description="Build your week of balanced meals, then log a day's plan in one tap."
        actions={
          <>
            <Button
              variant="soft"
              onClick={() => {
                actions.setDayPlan(day, generatePlan());
                toast.success(`New plan generated for ${DAYS[day]}`);
              }}
            >
              <Sparkles /> Auto-generate
            </Button>
            <Button
              onClick={() => {
                const count = plan ? Object.values(plan).flat().length : 0;
                if (!count) { toast.error("This day's plan is empty"); return; }
                actions.logPlanToDay(day);
                toast.success(`${count} items logged to today`);
              }}
            >
              <ClipboardCheck /> Log to today
            </Button>
          </>
        }
      />

      {/* Week strip */}
      <div className="mb-6 grid grid-cols-7 gap-2">
        {DAYS.map((d, i) => {
          const t = planTotals(s.plan[String(i)], foods);
          const active = i === day;
          const isToday = i === (new Date().getDay() + 6) % 7;
          return (
            <button
              key={d}
              onClick={() => setDay(i)}
              className={cn(
                "flex flex-col items-center rounded-2xl border px-1 py-3 transition-all",
                active ? "border-primary bg-primary text-primary-foreground shadow-glow" : "bg-card shadow-soft hover:border-primary/40",
              )}
            >
              <span className={cn("text-xs font-medium", !active && "text-muted-foreground")}>{d.slice(0, 3)}</span>
              <span className="mt-1 font-display text-sm font-semibold sm:text-base">{Math.round(t.calories)}</span>
              <span className={cn("text-[10px]", active ? "opacity-80" : "text-muted-foreground")}>kcal</span>
              {isToday && <span className={cn("mt-1 size-1.5 rounded-full", active ? "bg-primary-foreground" : "bg-primary")} />}
            </button>
          );
        })}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="grid gap-4 sm:grid-cols-2 lg:col-span-2">
          {MEALS.map((m) => {
            const ids = plan?.[m.id] ?? [];
            const kcal = ids.reduce((a, id) => a + (foods.find((f) => f.id === id)?.calories ?? 0), 0);
            return (
              <Card key={m.id} className="flex flex-col p-5 animate-fade-up">
                <div className="flex items-center gap-3">
                  <span className="grid size-10 place-items-center rounded-xl bg-secondary text-xl">{m.emoji}</span>
                  <div className="flex-1">
                    <h2 className="font-display font-semibold">{m.label}</h2>
                    <p className="text-xs text-muted-foreground">{m.time}</p>
                  </div>
                  <span className="rounded-full bg-muted px-2.5 py-1 text-xs font-semibold">{kcal} kcal</span>
                </div>
                <ul className="mt-4 flex-1 space-y-2">
                  {ids.length === 0 && <li className="rounded-xl border border-dashed p-4 text-center text-sm text-muted-foreground">No items planned</li>}
                  {ids.map((id, idx) => {
                    const f = foods.find((x) => x.id === id);
                    if (!f) return null;
                    return (
                      <li key={`${id}-${idx}`} className="group flex items-center gap-3 rounded-xl bg-muted/60 px-3 py-2">
                        <span className="text-xl">{f.emoji}</span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-medium">{f.name}</span>
                          <span className="block text-xs text-muted-foreground">{f.calories} kcal · {f.protein}g protein</span>
                        </span>
                        <button
                          aria-label={`Remove ${f.name}`}
                          onClick={() => actions.removeFromPlan(day, m.id, idx)}
                          className="rounded-full p-1 text-muted-foreground transition-colors hover:bg-card hover:text-destructive"
                        >
                          <X className="size-4" />
                        </button>
                      </li>
                    );
                  })}
                </ul>
                <FoodPickerDialog
                  title={`Add to ${DAYS[day]} · ${m.label}`}
                  onPick={(f) => actions.addToPlan(day, m.id, f.id)}
                  trigger={
                    <Button variant="soft" size="sm" className="mt-4 w-full">
                      <Plus /> Add item
                    </Button>
                  }
                />
              </Card>
            );
          })}
        </div>

        <Card className="h-fit p-6 lg:sticky lg:top-24">
          <h2 className="font-display text-lg font-semibold">{DAYS[day]} overview</h2>
          <div className="my-5 flex justify-center">
            <ProgressRing value={totals.calories} max={goal} size={160} colorVar={totals.calories > goal ? "--protein" : "--primary"} trackVar="--secondary">
              <div>
                <Flame className="mx-auto size-5 text-primary" />
                <p className="font-display text-2xl font-semibold">{Math.round(totals.calories)}</p>
                <p className="text-xs text-muted-foreground">of {goal} kcal</p>
              </div>
            </ProgressRing>
          </div>
          <div className="space-y-4">
            <MacroBar label="Protein" value={totals.protein} goal={s.profile.proteinGoal} tone="protein" />
            <MacroBar label="Carbs" value={totals.carbs} goal={s.profile.carbsGoal} tone="carbs" />
            <MacroBar label="Fat" value={totals.fat} goal={s.profile.fatGoal} tone="fat" />
          </div>
          <p className="mt-5 rounded-xl bg-secondary p-3 text-sm text-secondary-foreground">
            {totals.calories === 0
              ? "Start adding foods or auto-generate a balanced plan."
              : Math.abs(totals.calories - goal) <= goal * 0.1
                ? "Great balance! This plan is within 10% of your calorie goal."
                : totals.calories < goal
                  ? `Add about ${Math.round(goal - totals.calories)} kcal to reach your goal.`
                  : `This plan is ${Math.round(totals.calories - goal)} kcal above your goal.`}
          </p>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                if (window.confirm(`Copy ${DAYS[day]}'s plan to every day of the week?`)) {
                  actions.copyPlanToAll(day);
                  toast.success("Plan copied to all days");
                }
              }}
            >
              <Copy /> Copy to week
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="hover:text-destructive"
              onClick={() => {
                actions.setDayPlan(day, { breakfast: [], lunch: [], dinner: [], snack: [] });
                toast.success(`${DAYS[day]} cleared`);
              }}
            >
              <Eraser /> Clear day
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
