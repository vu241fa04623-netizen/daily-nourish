import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Bar, BarChart, CartesianGrid, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis, Cell } from "recharts";
import { Droplets, GlassWater, Coffee, Milk, Undo2, RotateCcw, Trash2, Plus, Target, Lightbulb } from "lucide-react";
import { toast } from "sonner";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PageHeader, StatCard, EmptyState, chartTooltipStyle } from "@/components/nutri-ui";
import { actions, useNutri } from "@/lib/store";
import { addDays, parseKey, todayKey } from "@/lib/nutrition";

export const Route = createFileRoute("/water")({
  head: () => ({
    meta: [
      { title: "Water Intake Tracker — NutriTrack" },
      { name: "description", content: "Track your daily hydration with quick-add glasses and weekly trends." },
      { property: "og:title", content: "Water Intake Tracker — NutriTrack" },
      { property: "og:description", content: "Track your daily hydration with quick-add glasses and weekly trends." },
    ],
  }),
  component: WaterPage,
});

const QUICK = [
  { ml: 150, label: "Cup", icon: Coffee },
  { ml: 250, label: "Glass", icon: GlassWater },
  { ml: 350, label: "Mug", icon: Milk },
  { ml: 500, label: "Bottle", icon: Droplets },
];

const TIPS = [
  "Start your day with a glass of water before coffee.",
  "Keep a reusable bottle within reach while you work.",
  "Eat water-rich foods like cucumber, oranges and watermelon.",
  "Drink a glass of water before each meal.",
];

function WaterPage() {
  const s = useNutri();
  const today = todayKey();
  const entries = s.water[today] ?? [];
  const total = entries.reduce((a, w) => a + w.ml, 0);
  const goal = s.profile.waterGoal;
  const pct = Math.min(100, (total / goal) * 100);
  const [custom, setCustom] = useState("");
  const [goalInput, setGoalInput] = useState(String(goal));

  const week = Array.from({ length: 7 }, (_, i) => {
    const key = addDays(today, i - 6);
    return {
      day: parseKey(key).toLocaleDateString(undefined, { weekday: "short" }),
      ml: (s.water[key] ?? []).reduce((a, w) => a + w.ml, 0),
    };
  });
  const avg = Math.round(week.reduce((a, d) => a + d.ml, 0) / 7);
  const goalDays = week.filter((d) => d.ml >= goal).length;

  const add = (ml: number) => {
    const before = total;
    actions.addWater(ml);
    if (before < goal && before + ml >= goal) toast.success("🎉 Daily water goal reached! Great job.");
    else toast.success(`+${ml} ml logged`);
  };

  return (
    <div>
      <PageHeader
        title="Water Intake"
        description="Stay hydrated — every glass counts toward your daily goal."
        actions={
          <>
            <Button variant="outline" disabled={!entries.length} onClick={() => { actions.undoWater(); toast("Last entry removed"); }}>
              <Undo2 /> Undo
            </Button>
            <Button
              variant="outline"
              disabled={!entries.length}
              onClick={() => {
                if (window.confirm("Reset today's water intake?")) {
                  actions.resetWater();
                  toast.success("Today's water reset");
                }
              }}
            >
              <RotateCcw /> Reset
            </Button>
          </>
        }
      />

      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="flex flex-col items-center p-6 lg:col-span-2">
          {/* Glass visual */}
          <div className="relative mt-2 h-72 w-48 overflow-hidden rounded-b-[3rem] rounded-t-2xl border-4 border-water/25 bg-water-soft">
            <div className="absolute inset-x-0 bottom-0 bg-gradient-water transition-all duration-700 ease-out" style={{ height: `${pct}%` }}>
              <svg className="absolute -top-3 left-0 h-4 w-[200%] animate-wave text-water/60" viewBox="0 0 200 10" preserveAspectRatio="none" fill="currentColor">
                <path d="M0 5 Q 12.5 0 25 5 T 50 5 T 75 5 T 100 5 T 125 5 T 150 5 T 175 5 T 200 5 V10 H0 Z" />
              </svg>
            </div>
            <div className="absolute inset-0 grid place-items-center text-center">
              <div className="rounded-2xl bg-card/80 px-4 py-2 backdrop-blur-sm">
                <p className="font-display text-3xl font-semibold text-foreground">{Math.round(pct)}%</p>
                <p className="text-xs text-muted-foreground">{total} / {goal} ml</p>
              </div>
            </div>
          </div>
          <p className="mt-5 text-sm text-muted-foreground">
            {total >= goal ? "Goal achieved — you're fully hydrated! 💧" : `${goal - total} ml to go`}
          </p>

          <div className="mt-5 grid w-full grid-cols-4 gap-2">
            {QUICK.map((q) => (
              <button
                key={q.ml}
                onClick={() => add(q.ml)}
                className="flex flex-col items-center gap-1 rounded-2xl border bg-card p-3 transition-all hover:-translate-y-0.5 hover:border-water/50 hover:bg-water-soft active:scale-95"
              >
                <q.icon className="size-5 text-water" />
                <span className="text-xs font-semibold">{q.ml} ml</span>
                <span className="text-[10px] text-muted-foreground">{q.label}</span>
              </button>
            ))}
          </div>

          <form
            className="mt-4 flex w-full gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              const v = Number(custom);
              if (!v || v <= 0 || v > 3000) { toast.error("Enter an amount between 1 and 3000 ml"); return; }
              add(v);
              setCustom("");
            }}
          >
            <Input type="number" placeholder="Custom amount (ml)" value={custom} onChange={(e) => setCustom(e.target.value)} className="h-10 rounded-xl" />
            <Button type="submit" variant="water" className="h-10">
              <Plus /> Add
            </Button>
          </form>
        </Card>

        <div className="space-y-6 lg:col-span-3">
          <div className="grid grid-cols-3 gap-4">
            <StatCard icon={Droplets} tone="water" label="Today" value={(total / 1000).toFixed(2)} unit="L" />
            <StatCard icon={GlassWater} tone="water" label="7-day avg" value={(avg / 1000).toFixed(2)} unit="L" />
            <StatCard icon={Target} tone="primary" label="Goal days" value={`${goalDays}/7`} />
          </div>

          <Card className="p-6">
            <h2 className="font-display text-lg font-semibold">This week</h2>
            <div className="mt-4 h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={week} margin={{ left: -12, right: 8, top: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
                  <XAxis dataKey="day" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
                  <YAxis tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
                  <Tooltip {...chartTooltipStyle} cursor={{ fill: "var(--water-soft)" }} formatter={(v: number) => [`${v} ml`, "Water"]} />
                  <ReferenceLine y={goal} stroke="var(--water)" strokeDasharray="5 5" />
                  <Bar dataKey="ml" radius={[8, 8, 0, 0]} maxBarSize={36}>
                    {week.map((d, i) => (
                      <Cell key={i} fill={d.ml >= goal ? "var(--water)" : "color-mix(in oklab, var(--water) 45%, transparent)"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card className="p-6">
              <h2 className="font-display text-lg font-semibold">Today's log</h2>
              <div className="mt-3 max-h-64 space-y-2 overflow-y-auto pr-1">
                {entries.length === 0 ? (
                  <EmptyState icon={Droplets} title="No water yet" text="Tap a quick-add button to log your first glass." />
                ) : (
                  [...entries].reverse().map((w) => (
                    <div key={w.id} className="flex items-center gap-3 rounded-xl bg-water-soft/60 px-3 py-2">
                      <GlassWater className="size-4 text-water" />
                      <span className="flex-1 text-sm font-medium">{w.ml} ml</span>
                      <span className="text-xs text-muted-foreground">
                        {new Date(w.time).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}
                      </span>
                      <button aria-label="Delete entry" onClick={() => actions.removeWater(w.id)} className="rounded-full p-1 text-muted-foreground hover:bg-card hover:text-destructive">
                        <Trash2 className="size-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </Card>

            <Card className="p-6">
              <h2 className="font-display text-lg font-semibold">Daily goal</h2>
              <div className="mt-3 flex gap-2">
                <Input type="number" step={250} value={goalInput} onChange={(e) => setGoalInput(e.target.value)} className="h-10 rounded-xl" />
                <Button
                  className="h-10"
                  onClick={() => {
                    const v = Number(goalInput);
                    if (!v || v < 500 || v > 8000) { toast.error("Goal should be 500–8000 ml"); return; }
                    actions.updateProfile({ waterGoal: v });
                    toast.success("Water goal updated");
                  }}
                >
                  Save
                </Button>
              </div>
              <div className="mt-5 space-y-2">
                <p className="flex items-center gap-2 text-sm font-semibold">
                  <Lightbulb className="size-4 text-warning" /> Hydration tips
                </p>
                {TIPS.map((t) => (
                  <p key={t} className="rounded-xl bg-muted px-3 py-2 text-xs text-muted-foreground">{t}</p>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
