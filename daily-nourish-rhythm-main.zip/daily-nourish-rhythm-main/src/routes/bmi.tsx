import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Line, LineChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Calculator, Save, Trash2, Scale, Ruler, HeartPulse, History } from "lucide-react";
import { toast } from "sonner";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PageHeader, EmptyState, chartTooltipStyle } from "@/components/nutri-ui";
import { cn } from "@/lib/utils";
import { actions, useNutri } from "@/lib/store";
import { bmiCategory, calcBmi, healthyWeightRange, parseKey, type BmiCategory } from "@/lib/nutrition";

export const Route = createFileRoute("/bmi")({
  head: () => ({
    meta: [
      { title: "BMI Calculator — NutriTrack" },
      { name: "description", content: "Calculate your Body Mass Index, see your healthy weight range and track progress." },
      { property: "og:title", content: "BMI Calculator — NutriTrack" },
      { property: "og:description", content: "Calculate your Body Mass Index, see your healthy weight range and track progress." },
    ],
  }),
  component: BmiPage,
});

const CATEGORY_STYLE: Record<BmiCategory, { badge: string; text: string; advice: string }> = {
  Underweight: { badge: "bg-carbs-soft text-carbs", text: "text-carbs", advice: "Consider nutrient-dense meals and strength training to build healthy mass." },
  Normal: { badge: "bg-secondary text-secondary-foreground", text: "text-primary-deep", advice: "You're in the healthy range. Keep up balanced eating and regular activity!" },
  Overweight: { badge: "bg-warning-soft text-warning", text: "text-warning", advice: "Small changes like more vegetables and daily walks can make a big difference." },
  Obese: { badge: "bg-protein-soft text-destructive", text: "text-destructive", advice: "Consider speaking with a healthcare professional for a personalised plan." },
};

const SEGMENTS = [
  { label: "Under", range: "< 18.5", cls: "bg-carbs", from: 12, to: 18.5 },
  { label: "Normal", range: "18.5–24.9", cls: "bg-primary", from: 18.5, to: 25 },
  { label: "Over", range: "25–29.9", cls: "bg-fat", from: 25, to: 30 },
  { label: "Obese", range: "30+", cls: "bg-destructive", from: 30, to: 40 },
];

function BmiPage() {
  const s = useNutri();
  const last = s.bmi[s.bmi.length - 1];
  const [unit, setUnit] = useState<"metric" | "imperial">("metric");
  const [cm, setCm] = useState(String(last?.height ?? 170));
  const [kg, setKg] = useState(String(last?.weight ?? 70));
  const [ft, setFt] = useState("5");
  const [inch, setInch] = useState("7");
  const [lb, setLb] = useState("154");
  const [result, setResult] = useState<{ bmi: number; height: number; weight: number } | null>(
    last ? { bmi: last.bmi, height: last.height, weight: last.weight } : null,
  );

  const calculate = () => {
    let h: number, w: number;
    if (unit === "metric") {
      h = Number(cm);
      w = Number(kg);
    } else {
      h = (Number(ft) * 12 + Number(inch)) * 2.54;
      w = Number(lb) * 0.453592;
    }
    if (!h || !w || h < 80 || h > 250 || w < 20 || w > 350) {
      toast.error("Please enter a realistic height and weight");
      return;
    }
    h = Math.round(h * 10) / 10;
    w = Math.round(w * 10) / 10;
    setResult({ bmi: calcBmi(h, w), height: h, weight: w });
  };

  const switchUnit = (u: "metric" | "imperial") => {
    if (u === unit) return;
    if (u === "imperial") {
      const totalIn = Number(cm) / 2.54;
      setFt(String(Math.floor(totalIn / 12)));
      setInch(String(Math.round(totalIn % 12)));
      setLb(String(Math.round(Number(kg) / 0.453592)));
    } else {
      setCm(String(Math.round((Number(ft) * 12 + Number(inch)) * 2.54)));
      setKg(String(Math.round(Number(lb) * 0.453592 * 10) / 10));
    }
    setUnit(u);
  };

  const cat = result ? bmiCategory(result.bmi) : null;
  const range = result ? healthyWeightRange(result.height) : null;
  const markerPct = result ? Math.min(100, Math.max(0, ((result.bmi - 12) / (40 - 12)) * 100)) : 0;

  const history = s.bmi.map((b) => ({
    ...b,
    label: parseKey(b.date).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
  }));

  return (
    <div>
      <PageHeader title="BMI Calculator" description="Understand your Body Mass Index and track how it changes over time." />

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold">Your measurements</h2>
            <div className="flex rounded-xl bg-muted p-1">
              {(["metric", "imperial"] as const).map((u) => (
                <button
                  key={u}
                  onClick={() => switchUnit(u)}
                  className={cn(
                    "rounded-lg px-3 py-1.5 text-xs font-semibold capitalize transition-all",
                    unit === u ? "bg-card text-foreground shadow-soft" : "text-muted-foreground",
                  )}
                >
                  {u}
                </button>
              ))}
            </div>
          </div>

          <form
            className="mt-6 space-y-5"
            onSubmit={(e) => {
              e.preventDefault();
              calculate();
            }}
          >
            {unit === "metric" ? (
              <>
                <Field icon={Ruler} label="Height (cm)" value={cm} onChange={setCm} id="cm" />
                <Field icon={Scale} label="Weight (kg)" value={kg} onChange={setKg} id="kg" step="0.1" />
              </>
            ) : (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <Field icon={Ruler} label="Height (ft)" value={ft} onChange={setFt} id="ft" />
                  <Field icon={Ruler} label="Height (in)" value={inch} onChange={setInch} id="in" />
                </div>
                <Field icon={Scale} label="Weight (lb)" value={lb} onChange={setLb} id="lb" />
              </>
            )}
            <Button type="submit" className="h-11 w-full">
              <Calculator /> Calculate BMI
            </Button>
          </form>

          <div className="mt-6 grid grid-cols-4 gap-2 text-center">
            {SEGMENTS.map((sg) => (
              <div key={sg.label} className="rounded-xl bg-muted p-2">
                <span className={cn("mx-auto block h-1.5 w-8 rounded-full", sg.cls)} />
                <p className="mt-1.5 text-xs font-semibold">{sg.label}</p>
                <p className="text-[10px] text-muted-foreground">{sg.range}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card className="flex flex-col p-6">
          <h2 className="font-display text-lg font-semibold">Result</h2>
          {result && cat && range ? (
            <div className="flex flex-1 flex-col animate-fade-up">
              <div className="mt-6 text-center">
                <p className="text-sm text-muted-foreground">Your BMI</p>
                <p className={cn("font-display text-6xl font-semibold tracking-tight", CATEGORY_STYLE[cat].text)}>{result.bmi}</p>
                <span className={cn("mt-2 inline-block rounded-full px-3 py-1 text-sm font-semibold", CATEGORY_STYLE[cat].badge)}>{cat}</span>
              </div>

              <div className="relative mt-8">
                <div className="flex h-3 overflow-hidden rounded-full">
                  {SEGMENTS.map((sg) => (
                    <div key={sg.label} className={sg.cls} style={{ width: `${((sg.to - sg.from) / 28) * 100}%` }} />
                  ))}
                </div>
                <div className="absolute -top-1.5 transition-all duration-700" style={{ left: `calc(${markerPct}% - 12px)` }}>
                  <div className="size-6 rounded-full border-4 border-card bg-foreground shadow-card" />
                </div>
                <div className="mt-2 flex justify-between text-[10px] text-muted-foreground">
                  <span>12</span>
                  <span>18.5</span>
                  <span>25</span>
                  <span>30</span>
                  <span>40</span>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-2 gap-3">
                <div className="rounded-xl bg-muted p-3">
                  <p className="text-xs text-muted-foreground">Healthy weight range</p>
                  <p className="font-display font-semibold">
                    {range[0]} – {range[1]} kg
                  </p>
                </div>
                <div className="rounded-xl bg-muted p-3">
                  <p className="text-xs text-muted-foreground">Height · Weight</p>
                  <p className="font-display font-semibold">
                    {result.height} cm · {result.weight} kg
                  </p>
                </div>
              </div>
              <p className="mt-4 flex gap-2 rounded-xl bg-secondary p-3 text-sm text-secondary-foreground">
                <HeartPulse className="mt-0.5 size-4 shrink-0" />
                {CATEGORY_STYLE[cat].advice}
              </p>
              <div className="mt-auto pt-4" />
              <Button
                variant="soft"
                className="w-full"
                onClick={() => {
                  actions.addBmi(result.height, result.weight);
                  toast.success("BMI saved to your history");
                }}
              >
                <Save /> Save to history
              </Button>
            </div>
          ) : (
            <div className="flex flex-1 items-center">
              <EmptyState icon={Calculator} title="No result yet" text="Enter your height and weight, then press Calculate." />
            </div>
          )}
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        <Card className="p-6 lg:col-span-3">
          <h2 className="font-display text-lg font-semibold">Weight & BMI trend</h2>
          {history.length < 2 ? (
            <div className="mt-4">
              <EmptyState icon={History} title="Not enough data" text="Save at least two BMI results to see your trend." />
            </div>
          ) : (
            <div className="mt-4 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={history} margin={{ left: -12, right: 8, top: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
                  <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
                  <YAxis yAxisId="w" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" domain={["dataMin - 2", "dataMax + 2"]} />
                  <YAxis yAxisId="b" orientation="right" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" domain={["dataMin - 1", "dataMax + 1"]} />
                  <Tooltip {...chartTooltipStyle} />
                  <Line yAxisId="w" type="monotone" dataKey="weight" name="Weight (kg)" stroke="var(--primary)" strokeWidth={2.5} dot={{ r: 4, fill: "var(--primary)" }} />
                  <Line yAxisId="b" type="monotone" dataKey="bmi" name="BMI" stroke="var(--carbs)" strokeWidth={2} strokeDasharray="5 4" dot={{ r: 3, fill: "var(--carbs)" }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>

        <Card className="p-6 lg:col-span-2">
          <h2 className="font-display text-lg font-semibold">History</h2>
          <div className="mt-3 max-h-64 space-y-2 overflow-y-auto pr-1">
            {history.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">No saved results.</p>}
            {[...history].reverse().map((b) => {
              const c = bmiCategory(b.bmi);
              return (
                <div key={b.id} className="flex items-center gap-3 rounded-xl border px-3 py-2.5">
                  <div className="flex-1">
                    <p className="text-sm font-semibold">{b.label}</p>
                    <p className="text-xs text-muted-foreground">{b.weight} kg · {b.height} cm</p>
                  </div>
                  <span className={cn("rounded-full px-2.5 py-0.5 text-xs font-semibold", CATEGORY_STYLE[c].badge)}>{b.bmi}</span>
                  <button aria-label="Delete record" onClick={() => { actions.removeBmi(b.id); toast("Record deleted"); }} className="rounded-full p-1 text-muted-foreground hover:bg-muted hover:text-destructive">
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  );
}

function Field({
  icon: Icon,
  label,
  value,
  onChange,
  id,
  step,
}: {
  icon: typeof Ruler;
  label: string;
  value: string;
  onChange: (v: string) => void;
  id: string;
  step?: string;
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <Icon className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input id={id} type="number" step={step} value={value} onChange={(e) => onChange(e.target.value)} className="h-11 rounded-xl pl-9" />
      </div>
    </div>
  );
}
