export type FoodCategory = "Fruits" | "Vegetables" | "Proteins" | "Grains" | "Dairy" | "Snacks" | "Drinks";

export interface Food {
  id: string;
  name: string;
  emoji: string;
  category: FoodCategory;
  serving: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sugar: number;
  sodium: number; // mg
  description: string;
  vitamins: string[];
}

export const FOOD_CATEGORIES: FoodCategory[] = [
  "Fruits",
  "Vegetables",
  "Proteins",
  "Grains",
  "Dairy",
  "Snacks",
  "Drinks",
];

export const FOODS: Food[] = [
  { id: "banana", name: "Banana", emoji: "🍌", category: "Fruits", serving: "1 medium (118g)", calories: 105, protein: 1.3, carbs: 27, fat: 0.4, fiber: 3.1, sugar: 14, sodium: 1, description: "A quick energy source rich in potassium, great before workouts.", vitamins: ["Potassium", "Vitamin B6", "Vitamin C"] },
  { id: "apple", name: "Apple", emoji: "🍎", category: "Fruits", serving: "1 medium (182g)", calories: 95, protein: 0.5, carbs: 25, fat: 0.3, fiber: 4.4, sugar: 19, sodium: 2, description: "Crunchy, hydrating and packed with soluble fiber for steady energy.", vitamins: ["Vitamin C", "Potassium"] },
  { id: "blueberries", name: "Blueberries", emoji: "🫐", category: "Fruits", serving: "1 cup (148g)", calories: 84, protein: 1.1, carbs: 21, fat: 0.5, fiber: 3.6, sugar: 15, sodium: 1, description: "Antioxidant powerhouse that supports brain and heart health.", vitamins: ["Vitamin K", "Vitamin C", "Manganese"] },
  { id: "avocado", name: "Avocado", emoji: "🥑", category: "Fruits", serving: "½ fruit (100g)", calories: 160, protein: 2, carbs: 9, fat: 15, fiber: 7, sugar: 0.7, sodium: 7, description: "Creamy source of heart-healthy monounsaturated fats.", vitamins: ["Vitamin K", "Folate", "Vitamin E"] },
  { id: "orange", name: "Orange", emoji: "🍊", category: "Fruits", serving: "1 medium (131g)", calories: 62, protein: 1.2, carbs: 15, fat: 0.2, fiber: 3.1, sugar: 12, sodium: 0, description: "Juicy citrus loaded with vitamin C for immune support.", vitamins: ["Vitamin C", "Folate", "Thiamine"] },
  { id: "broccoli", name: "Broccoli", emoji: "🥦", category: "Vegetables", serving: "1 cup (91g)", calories: 31, protein: 2.5, carbs: 6, fat: 0.3, fiber: 2.4, sugar: 1.5, sodium: 30, description: "Nutrient-dense cruciferous veggie with plant protein and fiber.", vitamins: ["Vitamin C", "Vitamin K", "Folate"] },
  { id: "spinach", name: "Spinach", emoji: "🥬", category: "Vegetables", serving: "2 cups raw (60g)", calories: 14, protein: 1.7, carbs: 2.2, fat: 0.2, fiber: 1.3, sugar: 0.3, sodium: 47, description: "Leafy green rich in iron, magnesium and folate.", vitamins: ["Vitamin K", "Vitamin A", "Iron"] },
  { id: "sweet-potato", name: "Sweet Potato", emoji: "🍠", category: "Vegetables", serving: "1 medium (130g)", calories: 112, protein: 2, carbs: 26, fat: 0.1, fiber: 3.9, sugar: 5.4, sodium: 72, description: "Complex carbs with a big dose of beta-carotene.", vitamins: ["Vitamin A", "Vitamin C", "Manganese"] },
  { id: "carrot", name: "Carrots", emoji: "🥕", category: "Vegetables", serving: "1 cup chopped (128g)", calories: 52, protein: 1.2, carbs: 12, fat: 0.3, fiber: 3.6, sugar: 6, sodium: 88, description: "Sweet, crunchy and excellent for eye health.", vitamins: ["Vitamin A", "Vitamin K", "Potassium"] },
  { id: "chicken-breast", name: "Grilled Chicken Breast", emoji: "🍗", category: "Proteins", serving: "100g cooked", calories: 165, protein: 31, carbs: 0, fat: 3.6, fiber: 0, sugar: 0, sodium: 74, description: "Lean, high-quality protein ideal for muscle recovery.", vitamins: ["Niacin", "Vitamin B6", "Selenium"] },
  { id: "salmon", name: "Salmon Fillet", emoji: "🐟", category: "Proteins", serving: "100g cooked", calories: 208, protein: 22, carbs: 0, fat: 13, fiber: 0, sugar: 0, sodium: 59, description: "Rich in omega-3 fatty acids that support heart and brain.", vitamins: ["Vitamin D", "Vitamin B12", "Omega-3"] },
  { id: "eggs", name: "Boiled Eggs", emoji: "🥚", category: "Proteins", serving: "2 large (100g)", calories: 155, protein: 13, carbs: 1.1, fat: 11, fiber: 0, sugar: 1.1, sodium: 124, description: "Complete protein with choline for brain health.", vitamins: ["Vitamin B12", "Choline", "Vitamin D"] },
  { id: "tofu", name: "Firm Tofu", emoji: "🧈", category: "Proteins", serving: "100g", calories: 144, protein: 17, carbs: 3, fat: 9, fiber: 2.3, sugar: 0.6, sodium: 14, description: "Versatile plant protein with calcium and iron.", vitamins: ["Calcium", "Iron", "Manganese"] },
  { id: "lentils", name: "Cooked Lentils", emoji: "🫘", category: "Proteins", serving: "1 cup (198g)", calories: 230, protein: 18, carbs: 40, fat: 0.8, fiber: 15.6, sugar: 3.6, sodium: 4, description: "Fiber-rich legume that keeps you full for hours.", vitamins: ["Folate", "Iron", "Manganese"] },
  { id: "oats", name: "Rolled Oats", emoji: "🥣", category: "Grains", serving: "½ cup dry (40g)", calories: 150, protein: 5, carbs: 27, fat: 2.5, fiber: 4, sugar: 1, sodium: 0, description: "Whole-grain breakfast staple with beta-glucan fiber.", vitamins: ["Manganese", "Phosphorus", "Magnesium"] },
  { id: "brown-rice", name: "Brown Rice", emoji: "🍚", category: "Grains", serving: "1 cup cooked (195g)", calories: 216, protein: 5, carbs: 45, fat: 1.8, fiber: 3.5, sugar: 0.7, sodium: 10, description: "Whole grain carb source for sustained energy.", vitamins: ["Manganese", "Selenium", "Magnesium"] },
  { id: "quinoa", name: "Quinoa", emoji: "🌾", category: "Grains", serving: "1 cup cooked (185g)", calories: 222, protein: 8, carbs: 39, fat: 3.6, fiber: 5.2, sugar: 1.6, sodium: 13, description: "Gluten-free seed with all nine essential amino acids.", vitamins: ["Manganese", "Magnesium", "Folate"] },
  { id: "whole-wheat-bread", name: "Whole Wheat Toast", emoji: "🍞", category: "Grains", serving: "2 slices (64g)", calories: 160, protein: 8, carbs: 28, fat: 2, fiber: 4, sugar: 3, sodium: 260, description: "Fiber-rich bread for balanced sandwiches and toast.", vitamins: ["Manganese", "Selenium", "Thiamine"] },
  { id: "greek-yogurt", name: "Greek Yogurt", emoji: "🥛", category: "Dairy", serving: "1 cup (200g)", calories: 146, protein: 20, carbs: 8, fat: 3.8, fiber: 0, sugar: 7, sodium: 68, description: "Thick, protein-packed and full of gut-friendly probiotics.", vitamins: ["Calcium", "Vitamin B12", "Probiotics"] },
  { id: "cottage-cheese", name: "Cottage Cheese", emoji: "🧀", category: "Dairy", serving: "½ cup (113g)", calories: 110, protein: 12.5, carbs: 4, fat: 5, fiber: 0, sugar: 3, sodium: 400, description: "Slow-digesting casein protein, perfect for evenings.", vitamins: ["Calcium", "Selenium", "Vitamin B12"] },
  { id: "almond-milk", name: "Almond Milk", emoji: "🥛", category: "Dairy", serving: "1 cup (240ml)", calories: 39, protein: 1, carbs: 3.4, fat: 2.5, fiber: 0.5, sugar: 0, sodium: 170, description: "Light, dairy-free milk alternative fortified with calcium.", vitamins: ["Calcium", "Vitamin E", "Vitamin D"] },
  { id: "almonds", name: "Almonds", emoji: "🌰", category: "Snacks", serving: "1 oz (28g)", calories: 164, protein: 6, carbs: 6, fat: 14, fiber: 3.5, sugar: 1.2, sodium: 0, description: "Crunchy snack with healthy fats, vitamin E and magnesium.", vitamins: ["Vitamin E", "Magnesium", "Riboflavin"] },
  { id: "hummus", name: "Hummus", emoji: "🥙", category: "Snacks", serving: "¼ cup (60g)", calories: 166, protein: 4.7, carbs: 8.6, fat: 9.6, fiber: 3.6, sugar: 0.2, sodium: 230, description: "Chickpea dip with plant protein and fiber.", vitamins: ["Folate", "Manganese", "Copper"] },
  { id: "dark-chocolate", name: "Dark Chocolate 85%", emoji: "🍫", category: "Snacks", serving: "2 squares (20g)", calories: 120, protein: 2, carbs: 7, fat: 10, fiber: 2.5, sugar: 3, sodium: 4, description: "A rich treat with flavonoids — enjoy in moderation.", vitamins: ["Iron", "Magnesium", "Copper"] },
  { id: "protein-bar", name: "Protein Bar", emoji: "🍫", category: "Snacks", serving: "1 bar (60g)", calories: 210, protein: 20, carbs: 22, fat: 7, fiber: 6, sugar: 5, sodium: 180, description: "Convenient on-the-go protein boost.", vitamins: ["Calcium", "Iron"] },
  { id: "green-smoothie", name: "Green Smoothie", emoji: "🥤", category: "Drinks", serving: "1 glass (350ml)", calories: 180, protein: 5, carbs: 36, fat: 2, fiber: 6, sugar: 22, sodium: 60, description: "Spinach, banana and mango blended for a vitamin-packed sip.", vitamins: ["Vitamin C", "Vitamin K", "Potassium"] },
  { id: "black-coffee", name: "Black Coffee", emoji: "☕", category: "Drinks", serving: "1 cup (240ml)", calories: 2, protein: 0.3, carbs: 0, fat: 0, fiber: 0, sugar: 0, sodium: 5, description: "Zero-calorie pick-me-up with antioxidants.", vitamins: ["Riboflavin", "Potassium"] },
  { id: "orange-juice", name: "Fresh Orange Juice", emoji: "🧃", category: "Drinks", serving: "1 cup (248ml)", calories: 112, protein: 1.7, carbs: 26, fat: 0.5, fiber: 0.5, sugar: 21, sodium: 2, description: "Refreshing source of vitamin C — mind the natural sugars.", vitamins: ["Vitamin C", "Folate", "Potassium"] },
];

export const getFood = (id: string) => FOODS.find((f) => f.id === id);
