export type MealType = "breakfast" | "lunch" | "dinner" | "snack";

export const MEALS: { id: MealType; label: string; emoji: string; time: string }[] = [
  { id: "breakfast", label: "Breakfast", emoji: "🌅", time: "7:00 – 10:00" },
  { id: "lunch", label: "Lunch", emoji: "☀️", time: "12:00 – 14:00" },
  { id: "dinner", label: "Dinner", emoji: "🌙", time: "18:00 – 21:00" },
  { id: "snack", label: "Snacks", emoji: "🍿", time: "Anytime" },
];

export interface Macros {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface LogEntry extends Macros {
  id: string;
  foodId?: string;
  name: string;
  emoji: string;
  servings: number;
  meal: MealType;
  time: string;
}

/** YYYY-MM-DD in local time */
export function dateKey(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function parseKey(key: string): Date {
  const [y = 1970, m = 1, d = 1] = key.split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function addDays(key: string, n: number): string {
  const d = parseKey(key);
  d.setDate(d.getDate() + n);
  return dateKey(d);
}

export function todayKey(): string {
  return dateKey(new Date());
}

/** Monday-start week containing the given date */
export function weekStart(key: string): string {
  const d = parseKey(key);
  const dow = (d.getDay() + 6) % 7; // Mon=0
  d.setDate(d.getDate() - dow);
  return dateKey(d);
}

export function sumEntries(entries: LogEntry[]): Macros {
  return entries.reduce<Macros>(
    (acc, e) => ({
      calories: acc.calories + e.calories * e.servings,
      protein: acc.protein + e.protein * e.servings,
      carbs: acc.carbs + e.carbs * e.servings,
      fat: acc.fat + e.fat * e.servings,
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 },
  );
}

export function calcBmi(heightCm: number, weightKg: number): number {
  if (heightCm <= 0 || weightKg <= 0) return 0;
  const m = heightCm / 100;
  return Math.round((weightKg / (m * m)) * 10) / 10;
}

export type BmiCategory = "Underweight" | "Normal" | "Overweight" | "Obese";

export function bmiCategory(bmi: number): BmiCategory {
  if (bmi < 18.5) return "Underweight";
  if (bmi < 25) return "Normal";
  if (bmi < 30) return "Overweight";
  return "Obese";
}

/** Healthy weight range (BMI 18.5–24.9) for a height, in kg */
export function healthyWeightRange(heightCm: number): [number, number] {
  const m = heightCm / 100;
  return [Math.round(18.5 * m * m * 10) / 10, Math.round(24.9 * m * m * 10) / 10];
}

export const round = (n: number, digits = 0) => {
  const f = 10 ** digits;
  return Math.round(n * f) / f;
};

export function uid(): string {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}
