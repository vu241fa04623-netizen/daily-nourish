import { useSyncExternalStore } from "react";
import { FOODS, type Food } from "@/data/foods";
import {
  addDays,
  dateKey,
  type LogEntry,
  type MealType,
  todayKey,
  uid,
  calcBmi,
} from "./nutrition";

export interface WaterEntry {
  id: string;
  ml: number;
  time: string;
}

export interface BmiRecord {
  id: string;
  date: string;
  height: number;
  weight: number;
  bmi: number;
}

export interface Profile {
  name: string;
  calorieGoal: number;
  waterGoal: number; // ml
  proteinGoal: number;
  carbsGoal: number;
  fatGoal: number;
}

export type DayPlan = Record<MealType, string[]>;

export interface NutriState {
  version: 1;
  profile: Profile;
  logs: Record<string, LogEntry[]>;
  water: Record<string, WaterEntry[]>;
  plan: Record<string, DayPlan>; // "0".."6" Monday..Sunday
  bmi: BmiRecord[];
  favorites: string[];
  customFoods: Food[];
}

const STORAGE_KEY = "nutritrack:v1";

export const DEFAULT_PROFILE: Profile = {
  name: "Alex",
  calorieGoal: 2000,
  waterGoal: 2500,
  proteinGoal: 120,
  carbsGoal: 230,
  fatGoal: 65,
};

const emptyPlan = (): DayPlan => ({ breakfast: [], lunch: [], dinner: [], snack: [] });

export function emptyState(): NutriState {
  const plan: Record<string, DayPlan> = {};
  for (let i = 0; i < 7; i++) plan[String(i)] = emptyPlan();
  return {
    version: 1,
    profile: { ...DEFAULT_PROFILE },
    logs: {},
    water: {},
    plan,
    bmi: [],
    favorites: [],
    customFoods: [],
  };
}

function makeEntry(foodId: string, meal: MealType, servings: number, day: string, hour: number): LogEntry {
  const f = FOODS.find((x) => x.id === foodId)!;
  const t = new Date(`${day}T00:00:00`);
  t.setHours(hour, (hour * 7) % 60);
  return {
    id: uid(),
    foodId,
    name: f.name,
    emoji: f.emoji,
    calories: f.calories,
    protein: f.protein,
    carbs: f.carbs,
    fat: f.fat,
    servings,
    meal,
    time: t.toISOString(),
  };
}

/** Builds friendly demo data so every page looks alive on first visit. */
export function createSeedState(): NutriState {
  const s = emptyState();
  const today = todayKey();
  const menus: [string, MealType, number, number][][] = [
    [["oats", "breakfast", 1, 8], ["blueberries", "breakfast", 1, 8], ["chicken-breast", "lunch", 1.5, 13], ["brown-rice", "lunch", 1, 13], ["broccoli", "lunch", 1, 13], ["salmon", "dinner", 1.5, 19], ["sweet-potato", "dinner", 1, 19], ["almonds", "snack", 1, 16]],
    [["eggs", "breakfast", 1, 8], ["whole-wheat-bread", "breakfast", 1, 8], ["lentils", "lunch", 1, 13], ["spinach", "lunch", 1, 13], ["tofu", "dinner", 1.5, 19], ["quinoa", "dinner", 1, 19], ["greek-yogurt", "snack", 1, 16], ["apple", "snack", 1, 11]],
    [["greek-yogurt", "breakfast", 1, 8], ["banana", "breakfast", 1, 8], ["chicken-breast", "lunch", 1, 13], ["quinoa", "lunch", 1, 13], ["avocado", "lunch", 1, 13], ["salmon", "dinner", 1, 19], ["broccoli", "dinner", 1, 19], ["dark-chocolate", "snack", 1, 21], ["protein-bar", "snack", 1, 16]],
    [["green-smoothie", "breakfast", 1, 8], ["eggs", "breakfast", 1, 8], ["hummus", "lunch", 1, 13], ["whole-wheat-bread", "lunch", 1, 13], ["carrot", "lunch", 1, 13], ["chicken-breast", "dinner", 1.5, 19], ["brown-rice", "dinner", 1.5, 19], ["orange", "snack", 1, 16]],
    [["oats", "breakfast", 1.5, 8], ["banana", "breakfast", 1, 8], ["tofu", "lunch", 1, 13], ["brown-rice", "lunch", 1, 13], ["spinach", "lunch", 1, 13], ["salmon", "dinner", 1, 19], ["sweet-potato", "dinner", 1.5, 19], ["cottage-cheese", "snack", 1, 21]],
    [["whole-wheat-bread", "breakfast", 1, 9], ["avocado", "breakfast", 1, 9], ["eggs", "breakfast", 1, 9], ["lentils", "lunch", 1.5, 14], ["quinoa", "dinner", 1, 19], ["chicken-breast", "dinner", 1, 19], ["broccoli", "dinner", 1, 19], ["almonds", "snack", 1, 16], ["orange-juice", "snack", 1, 11]],
  ];
  menus.forEach((menu, i) => {
    const day = addDays(today, -(6 - i));
    s.logs[day] = menu.map(([id, meal, sv, hr]) => makeEntry(id, meal, sv * 1.5, day, hr));
  });
  s.logs[today] = [
    makeEntry("oats", "breakfast", 1, today, 8),
    makeEntry("blueberries", "breakfast", 1, today, 8),
    makeEntry("black-coffee", "breakfast", 1, today, 8),
    makeEntry("greek-yogurt", "snack", 1, today, 11),
  ];

  const waterTotals = [2250, 2750, 1750, 2500, 3000, 2000];
  waterTotals.forEach((total, i) => {
    const day = addDays(today, -(6 - i));
    const entries: WaterEntry[] = [];
    let left = total;
    let hour = 8;
    while (left > 0) {
      const ml = Math.min(left, 250 * (1 + (hour % 2)));
      const t = new Date(`${day}T00:00:00`);
      t.setHours(hour);
      entries.push({ id: uid(), ml, time: t.toISOString() });
      left -= ml;
      hour += 2;
    }
    s.water[day] = entries;
  });
  const now = new Date();
  s.water[today] = [500, 250].map((ml, i) => {
    const t = new Date(now);
    t.setHours(Math.max(7, now.getHours() - 3 + i), 15);
    return { id: uid(), ml, time: t.toISOString() };
  });

  const weights = [76.4, 75.6, 74.9, 74.2];
  s.bmi = weights.map((w, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (3 - i) * 21);
    return { id: uid(), date: dateKey(d), height: 175, weight: w, bmi: calcBmi(175, w) };
  });

  const planTemplate: DayPlan[] = [
    { breakfast: ["oats", "banana"], lunch: ["chicken-breast", "quinoa", "broccoli"], dinner: ["salmon", "sweet-potato"], snack: ["almonds"] },
    { breakfast: ["greek-yogurt", "blueberries"], lunch: ["lentils", "spinach"], dinner: ["tofu", "brown-rice"], snack: ["apple"] },
    { breakfast: ["eggs", "whole-wheat-bread"], lunch: ["hummus", "carrot", "whole-wheat-bread"], dinner: ["chicken-breast", "brown-rice", "broccoli"], snack: ["protein-bar"] },
  ];
  for (let i = 0; i < 7; i++) {
    const p = planTemplate[i % planTemplate.length]!;
    s.plan[String(i)] = {
      breakfast: [...p.breakfast],
      lunch: [...p.lunch],
      dinner: [...p.dinner],
      snack: [...p.snack],
    };
  }
  s.favorites = ["avocado", "salmon", "greek-yogurt"];
  return s;
}

// ---------- external store ----------
let state: NutriState | null = null;
const listeners = new Set<() => void>();
const serverState = emptyState();

function load(): NutriState {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as NutriState;
      if (parsed && parsed.version === 1) return { ...emptyState(), ...parsed };
    }
  } catch {
    /* ignore corrupt data */
  }
  const seeded = createSeedState();
  persist(seeded);
  return seeded;
}

function persist(s: NutriState) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
  } catch {
    /* storage full or unavailable */
  }
}

function getSnapshot(): NutriState {
  if (typeof window === "undefined") return serverState;
  if (!state) state = load();
  return state;
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  const onStorage = (e: StorageEvent) => {
    if (e.key === STORAGE_KEY) {
      state = null;
      cb();
    }
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(cb);
    window.removeEventListener("storage", onStorage);
  };
}

function setState(updater: (s: NutriState) => NutriState) {
  state = updater(getSnapshot());
  persist(state);
  listeners.forEach((l) => l());
}

export function useNutri(): NutriState {
  return useSyncExternalStore(subscribe, getSnapshot, () => serverState);
}

export function allFoods(s: NutriState): Food[] {
  return [...FOODS, ...s.customFoods];
}

// ---------- actions ----------
export const actions = {
  addFood(food: Food, meal: MealType, servings: number, day: string = todayKey()) {
    const entry: LogEntry = {
      id: uid(),
      foodId: food.id,
      name: food.name,
      emoji: food.emoji,
      calories: food.calories,
      protein: food.protein,
      carbs: food.carbs,
      fat: food.fat,
      servings,
      meal,
      time: new Date().toISOString(),
    };
    setState((s) => ({ ...s, logs: { ...s.logs, [day]: [...(s.logs[day] ?? []), entry] } }));
  },
  removeEntry(day: string, id: string) {
    setState((s) => ({
      ...s,
      logs: { ...s.logs, [day]: (s.logs[day] ?? []).filter((e) => e.id !== id) },
    }));
  },
  updateServings(day: string, id: string, servings: number) {
    setState((s) => ({
      ...s,
      logs: {
        ...s.logs,
        [day]: (s.logs[day] ?? []).map((e) => (e.id === id ? { ...e, servings } : e)),
      },
    }));
  },
  clearDay(day: string) {
    setState((s) => ({ ...s, logs: { ...s.logs, [day]: [] } }));
  },
  addCustomFood(food: Omit<Food, "id">) {
    const f: Food = { ...food, id: `custom-${uid()}` };
    setState((s) => ({ ...s, customFoods: [...s.customFoods, f] }));
    return f;
  },
  toggleFavorite(id: string) {
    setState((s) => ({
      ...s,
      favorites: s.favorites.includes(id)
        ? s.favorites.filter((x) => x !== id)
        : [...s.favorites, id],
    }));
  },
  addWater(ml: number, day: string = todayKey()) {
    const entry: WaterEntry = { id: uid(), ml, time: new Date().toISOString() };
    setState((s) => ({ ...s, water: { ...s.water, [day]: [...(s.water[day] ?? []), entry] } }));
  },
  removeWater(id: string, day: string = todayKey()) {
    setState((s) => ({
      ...s,
      water: { ...s.water, [day]: (s.water[day] ?? []).filter((w) => w.id !== id) },
    }));
  },
  undoWater(day: string = todayKey()) {
    setState((s) => ({ ...s, water: { ...s.water, [day]: (s.water[day] ?? []).slice(0, -1) } }));
  },
  resetWater(day: string = todayKey()) {
    setState((s) => ({ ...s, water: { ...s.water, [day]: [] } }));
  },
  addToPlan(dayIdx: number, meal: MealType, foodId: string) {
    setState((s) => {
      const d = s.plan[String(dayIdx)] ?? emptyPlan();
      return { ...s, plan: { ...s.plan, [dayIdx]: { ...d, [meal]: [...d[meal], foodId] } } };
    });
  },
  removeFromPlan(dayIdx: number, meal: MealType, index: number) {
    setState((s) => {
      const d = s.plan[String(dayIdx)] ?? emptyPlan();
      return {
        ...s,
        plan: { ...s.plan, [dayIdx]: { ...d, [meal]: d[meal].filter((_, i) => i !== index) } },
      };
    });
  },
  setDayPlan(dayIdx: number, plan: DayPlan) {
    setState((s) => ({ ...s, plan: { ...s.plan, [dayIdx]: plan } }));
  },
  copyPlanToAll(dayIdx: number) {
    setState((s) => {
      const src = s.plan[String(dayIdx)] ?? emptyPlan();
      const plan: Record<string, DayPlan> = {};
      for (let i = 0; i < 7; i++)
        plan[String(i)] = {
          breakfast: [...src.breakfast],
          lunch: [...src.lunch],
          dinner: [...src.dinner],
          snack: [...src.snack],
        };
      return { ...s, plan };
    });
  },
  logPlanToDay(dayIdx: number, day: string = todayKey()) {
    setState((s) => {
      const p = s.plan[String(dayIdx)] ?? emptyPlan();
      const foods = allFoods(s);
      const entries: LogEntry[] = [];
      (Object.keys(p) as MealType[]).forEach((meal) => {
        p[meal].forEach((fid) => {
          const f = foods.find((x) => x.id === fid);
          if (!f) return;
          entries.push({
            id: uid(),
            foodId: f.id,
            name: f.name,
            emoji: f.emoji,
            calories: f.calories,
            protein: f.protein,
            carbs: f.carbs,
            fat: f.fat,
            servings: 1,
            meal,
            time: new Date().toISOString(),
          });
        });
      });
      return { ...s, logs: { ...s.logs, [day]: [...(s.logs[day] ?? []), ...entries] } };
    });
  },
  addBmi(height: number, weight: number) {
    const rec: BmiRecord = {
      id: uid(),
      date: todayKey(),
      height,
      weight,
      bmi: calcBmi(height, weight),
    };
    setState((s) => ({ ...s, bmi: [...s.bmi, rec] }));
  },
  removeBmi(id: string) {
    setState((s) => ({ ...s, bmi: s.bmi.filter((b) => b.id !== id) }));
  },
  updateProfile(p: Partial<Profile>) {
    setState((s) => ({ ...s, profile: { ...s.profile, ...p } }));
  },
  resetDemo() {
    setState(() => createSeedState());
  },
  clearAll() {
    setState(() => emptyState());
  },
};
