import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Flame,
  Apple,
  CalendarDays,
  Droplets,
  Scale,
  BarChart3,
  Leaf,
  Sparkles,
} from "lucide-react";

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

export const NAV_ITEMS = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Calorie Tracker", url: "/calories", icon: Flame },
  { title: "Food & Nutrition", url: "/foods", icon: Apple },
  { title: "Meal Planner", url: "/meal-planner", icon: CalendarDays },
  { title: "Water Intake", url: "/water", icon: Droplets },
  { title: "BMI Calculator", url: "/bmi", icon: Scale },
  { title: "Weekly Reports", url: "/reports", icon: BarChart3 },
] as const;

export function AppSidebar() {
  const { state, setOpenMobile } = useSidebar();
  const collapsed = state === "collapsed";
  const currentPath = useRouterState({ select: (r) => r.location.pathname });

  return (
    <Sidebar collapsible="icon" className="border-r-0">
      <SidebarHeader className="px-3 pt-5 pb-3">
        <Link to="/" className="flex items-center gap-2.5 px-1" onClick={() => setOpenMobile(false)}>
          <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-gradient-primary text-primary-foreground shadow-glow">
            <Leaf className="size-5" />
          </span>
          {!collapsed && (
            <span className="font-display text-lg font-semibold tracking-tight">
              Nutri<span className="text-primary">Track</span>
            </span>
          )}
        </Link>
      </SidebarHeader>

      <SidebarContent className="px-1">
        <SidebarGroup>
          <SidebarGroupLabel className="text-[11px] uppercase tracking-wider">Menu</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="gap-1">
              {NAV_ITEMS.map((item) => {
                const active = currentPath === item.url;
                return (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton
                      asChild
                      isActive={active}
                      tooltip={item.title}
                      className="h-10 rounded-xl px-3 font-medium text-muted-foreground transition-colors hover:bg-secondary/60 hover:text-foreground data-[active=true]:bg-secondary data-[active=true]:font-semibold data-[active=true]:text-secondary-foreground"
                    >
                      <Link to={item.url} onClick={() => setOpenMobile(false)}>
                        <item.icon className={active ? "text-primary" : ""} />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-3">
        {!collapsed && (
          <div className="rounded-2xl bg-gradient-hero p-4 text-primary-foreground">
            <Sparkles className="mb-2 size-5" />
            <p className="font-display text-sm font-semibold">Healthy habit tip</p>
            <p className="mt-1 text-xs leading-relaxed opacity-90">
              Fill half your plate with vegetables for an easy fiber boost.
            </p>
          </div>
        )}
      </SidebarFooter>
    </Sidebar>
  );
}
