import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { RotateCcw, Trash2 } from "lucide-react";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { actions, useNutri, type Profile } from "@/lib/store";

export function SettingsDialog({ trigger }: { trigger: ReactNode }) {
  const { profile } = useNutri();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Profile>(profile);

  const onOpenChange = (o: boolean) => {
    if (o) setForm(profile);
    setOpen(o);
  };

  const num = (k: keyof Profile) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: Number(e.target.value) }));

  const save = () => {
    if (!form.name.trim()) { toast.error("Please enter your name"); return; }
    if (form.calorieGoal < 800 || form.calorieGoal > 6000)
      { toast.error("Calorie goal should be between 800 and 6000"); return; }
    if (form.waterGoal < 500 || form.waterGoal > 8000)
      { toast.error("Water goal should be between 500 and 8000 ml"); return; }
    actions.updateProfile({ ...form, name: form.name.trim() });
    toast.success("Profile & goals updated");
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="rounded-2xl sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display">Profile & daily goals</DialogTitle>
          <DialogDescription>Personalise your targets. Everything is saved on this device.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2 sm:grid-cols-2">
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="name">Name</Label>
            <Input id="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cal">Calories (kcal)</Label>
            <Input id="cal" type="number" value={form.calorieGoal} onChange={num("calorieGoal")} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="water">Water (ml)</Label>
            <Input id="water" type="number" step={250} value={form.waterGoal} onChange={num("waterGoal")} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="protein">Protein (g)</Label>
            <Input id="protein" type="number" value={form.proteinGoal} onChange={num("proteinGoal")} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="carbs">Carbs (g)</Label>
            <Input id="carbs" type="number" value={form.carbsGoal} onChange={num("carbsGoal")} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="fat">Fat (g)</Label>
            <Input id="fat" type="number" value={form.fatGoal} onChange={num("fatGoal")} />
          </div>
        </div>
        <div className="flex flex-wrap gap-2 rounded-xl bg-muted p-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              actions.resetDemo();
              toast.success("Demo data restored");
              setOpen(false);
            }}
          >
            <RotateCcw /> Restore demo data
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="text-destructive"
            onClick={() => {
              if (window.confirm("Delete all your NutriTrack data on this device?")) {
                actions.clearAll();
                toast.success("All data cleared");
                setOpen(false);
              }
            }}
          >
            <Trash2 /> Clear all data
          </Button>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={save}>Save changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
