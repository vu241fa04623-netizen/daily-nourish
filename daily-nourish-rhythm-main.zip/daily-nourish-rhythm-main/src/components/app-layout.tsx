import type { ReactNode } from "react";
import { ClientOnly, useRouterState } from "@tanstack/react-router";
import { Settings } from "lucide-react";

import { SidebarInset, SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { AppSidebar, NAV_ITEMS } from "./app-sidebar";
import { SettingsDialog } from "./settings-dialog";
import { useNutri } from "@/lib/store";

function HeaderProfile() {
  const { profile } = useNutri();
  const today = new Date().toLocaleDateString(undefined, {
    weekday: "long",
    month: "short",
    day: "numeric",
  });
  return (
    <div className="flex items-center gap-2 sm:gap-3">
      <span className="hidden text-sm text-muted-foreground md:inline">{today}</span>
      <SettingsDialog
        trigger={
          <Button variant="ghost" size="icon" aria-label="Settings">
            <Settings />
          </Button>
        }
      />
      <SettingsDialog
        trigger={
          <button
            className="flex items-center gap-2 rounded-full border bg-card py-1 pr-3 pl-1 shadow-soft transition-colors hover:bg-muted"
            aria-label="Edit profile"
          >
            <span className="grid size-7 place-items-center rounded-full bg-gradient-primary text-xs font-semibold text-primary-foreground">
              {profile.name.slice(0, 1).toUpperCase() || "?"}
            </span>
            <span className="hidden text-sm font-medium sm:inline">{profile.name}</span>
          </button>
        }
      />
    </div>
  );
}

function PageSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="h-10 w-64 rounded-xl" />
      <div className="grid gap-4 md:grid-cols-3">
        <Skeleton className="h-40 rounded-2xl" />
        <Skeleton className="h-40 rounded-2xl" />
        <Skeleton className="h-40 rounded-2xl" />
      </div>
      <Skeleton className="h-72 rounded-2xl" />
    </div>
  );
}

export function AppLayout({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (r) => r.location.pathname });
  const current = NAV_ITEMS.find((n) => n.url === pathname);

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <AppSidebar />
        <SidebarInset className="bg-background">
          <header className="sticky top-0 z-20 flex h-16 items-center justify-between gap-3 border-b border-border/60 bg-background/80 px-4 backdrop-blur-md sm:px-6">
            <div className="flex items-center gap-2">
              <SidebarTrigger className="size-9 rounded-xl" />
              <span className="hidden font-display text-sm font-medium text-muted-foreground sm:inline">
                {current?.title ?? "NutriTrack"}
              </span>
            </div>
            <ClientOnly fallback={<Skeleton className="h-9 w-40 rounded-full" />}>
              <HeaderProfile />
            </ClientOnly>
          </header>
          <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
            <ClientOnly fallback={<PageSkeleton />}>{children}</ClientOnly>
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
