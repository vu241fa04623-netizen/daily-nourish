import { useMemo, useState, type ReactNode } from "react";
import { Search, Plus, Minus, Check } from "lucide-react";
import { toast } from "sonner";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import type { Food } from "@/data/foods";
import { MEALS, type MealType, todayKey } from "@/lib/nutrition";
import { actions, allFoods, useNutri } from "@/lib/store";

interface Props {
  trigger: ReactNode;
  defaultMeal?: MealType;
  day?: string;
  /** When provided, the dialog picks a food instead of logging it. */
  onPick?: (food: Food) => void;
  title?: string;
}

export function FoodPickerDialog({ trigger, defaultMeal = "breakfast", day, onPick, title }: Props) {
  const s = useNutri();
  const foods = allFoods(s);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Food | null>(null);
  const [meal, setMeal] = useState<MealType>(defaultMeal);
  const [servings, setServings] = useState(1);
  const [custom, setCustom] = useState({ name: "", calories: "", protein: "", carbs: "", fat: "" });

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q ? foods.filter((f) => f.name.toLowerCase().includes(q) || f.category.toLowerCase().includes(q)) : foods;
    return [...list].sort((a, b) => Number(s.favorites.includes(b.id)) - Number(s.favorites.includes(a.id)));
  }, [foods, query, s.favorites]);

  const reset = () => {
    setQuery("");
    setSelected(null);
    setServings(1);
    setMeal(defaultMeal);
    setCustom({ name: "", calories: "", protein: "", carbs: "", fat: "" });
  };

  const finish = (food: Food) => {
    if (onPick) {
      onPick(food);
      toast.success(`${food.name} added to plan`);
    } else {
      actions.addFood(food, meal, servings, day ?? todayKey());
      toast.success(`${food.name} logged`, {
        description: `${Math.round(food.calories * servings)} kcal added to ${MEALS.find((m) => m.id === meal)?.label}`,
      });
    }
    setOpen(false);
    reset();
  };

  const saveCustom = () => {
    const cal = Number(custom.calories);
    if (!custom.name.trim() || !cal || cal < 0) {
      toast.error("Enter a food name and calories");
      return;
    }
    const food = actions.addCustomFood({
      name: custom.name.trim(),
      emoji: "🍽️",
      category: "Snacks",
      serving: "1 serving",
      calories: cal,
      protein: Number(custom.protein) || 0,
      carbs: Number(custom.carbs) || 0,
      fat: Number(custom.fat) || 0,
      fiber: 0,
      sugar: 0,
      sodium: 0,
      description: "Your custom food.",
      vitamins: [],
    });
    finish(food);
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        if (!o) reset();
      }}
    >
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="rounded-2xl sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-display">{title ?? (onPick ? "Add to meal plan" : "Log food")}</DialogTitle>
          <DialogDescription>Search the food library or create your own item.</DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="library">
          <TabsList className="grid w-full grid-cols-2 rounded-xl">
            <TabsTrigger value="library" className="rounded-lg">Food library</TabsTrigger>
            <TabsTrigger value="custom" className="rounded-lg">Custom food</TabsTrigger>
          </TabsList>

          <TabsContent value="library" className="space-y-4">
            <div className="relative">
              <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                autoFocus
                placeholder="Search e.g. salmon, oats, fruits…"
                className="h-10 rounded-xl pl-9"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            <ScrollArea className="h-60 rounded-xl border">
              <div className="p-1.5">
                {results.length === 0 && <p className="p-6 text-center text-sm text-muted-foreground">No foods found.</p>}
                {results.map((f) => {
                  const active = selected?.id === f.id;
                  return (
                    <button
                      key={f.id}
                      onClick={() => setSelected(f)}
                      className={cn(
                        "flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-colors hover:bg-muted",
                        active && "bg-secondary hover:bg-secondary",
                      )}
                    >
                      <span className="grid size-9 place-items-center rounded-lg bg-muted text-lg">{f.emoji}</span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-medium">{f.name}</span>
                        <span className="block truncate text-xs text-muted-foreground">
                          {f.serving} · P {f.protein}g · C {f.carbs}g · F {f.fat}g
                        </span>
                      </span>
                      <span className="text-sm font-semibold">{f.calories}</span>
                      <span className="text-xs text-muted-foreground">kcal</span>
                      {active && <Check className="size-4 text-primary" />}
                    </button>
                  );
                })}
              </div>
            </ScrollArea>

            {selected && !onPick && (
              <div className="space-y-3 rounded-xl bg-muted/60 p-3">
                <div className="flex flex-wrap gap-1.5">
                  {MEALS.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => setMeal(m.id)}
                      className={cn(
                        "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                        meal === m.id ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:bg-secondary",
                      )}
                    >
                      {m.emoji} {m.label}
                    </button>
                  ))}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Servings</span>
                  <div className="flex items-center gap-2">
                    <Button size="icon" variant="outline" className="size-8" onClick={() => setServings((v) => Math.max(0.5, v - 0.5))}>
                      <Minus />
                    </Button>
                    <span className="w-10 text-center font-semibold">{servings}</span>
                    <Button size="icon" variant="outline" className="size-8" onClick={() => setServings((v) => Math.min(10, v + 0.5))}>
                      <Plus />
                    </Button>
                  </div>
                </div>
                <p className="text-right text-sm">
                  Total: <span className="font-semibold">{Math.round(selected.calories * servings)} kcal</span>
                </p>
              </div>
            )}

            <Button className="w-full" disabled={!selected} onClick={() => selected && finish(selected)}>
              <Plus /> {onPick ? "Add to plan" : "Add to log"}
            </Button>
          </TabsContent>

          <TabsContent value="custom" className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="cf-name">Food name</Label>
              <Input id="cf-name" placeholder="e.g. Homemade granola" value={custom.name} onChange={(e) => setCustom({ ...custom, name: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {(["calories", "protein", "carbs", "fat"] as const).map((k) => (
                <div key={k} className="space-y-1.5">
                  <Label htmlFor={`cf-${k}`} className="capitalize">
                    {k} {k === "calories" ? "(kcal)" : "(g)"}
                  </Label>
                  <Input id={`cf-${k}`} type="number" min={0} value={custom[k]} onChange={(e) => setCustom({ ...custom, [k]: e.target.value })} />
                </div>
              ))}
            </div>
            {!onPick && (
              <div className="flex flex-wrap gap-1.5">
                {MEALS.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setMeal(m.id)}
                    className={cn(
                      "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                      meal === m.id ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:bg-secondary",
                    )}
                  >
                    {m.emoji} {m.label}
                  </button>
                ))}
              </div>
            )}
            <Button className="w-full" onClick={saveCustom}>
              <Plus /> Save & {onPick ? "add to plan" : "log"}
            </Button>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
