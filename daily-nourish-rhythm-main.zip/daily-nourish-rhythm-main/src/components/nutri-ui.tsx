import type { ReactNode } from "react";
import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{title}</h1>
        {description && <p className="mt-1 text-sm text-muted-foreground sm:text-base">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

const toneClasses = {
  primary: "bg-secondary text-primary-deep",
  protein: "bg-protein-soft text-protein",
  carbs: "bg-carbs-soft text-carbs",
  fat: "bg-fat-soft text-warning",
  water: "bg-water-soft text-water",
  muted: "bg-muted text-muted-foreground",
} as const;

export type Tone = keyof typeof toneClasses;

export function IconTile({ icon: Icon, tone = "primary", className }: { icon: LucideIcon; tone?: Tone; className?: string }) {
  return (
    <span className={cn("grid size-10 shrink-0 place-items-center rounded-xl", toneClasses[tone], className)}>
      <Icon className="size-5" />
    </span>
  );
}

export function StatCard({
  icon,
  tone = "primary",
  label,
  value,
  unit,
  hint,
  className,
}: {
  icon: LucideIcon;
  tone?: Tone;
  label: string;
  value: ReactNode;
  unit?: string;
  hint?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("rounded-2xl border border-border/70 bg-card p-5 shadow-card animate-fade-up", className)}>
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-muted-foreground">{label}</span>
        <IconTile icon={icon} tone={tone} className="size-9" />
      </div>
      <div className="mt-3 flex items-baseline gap-1">
        <span className="font-display text-2xl font-semibold tracking-tight">{value}</span>
        {unit && <span className="text-sm text-muted-foreground">{unit}</span>}
      </div>
      {hint && <div className="mt-1 text-xs text-muted-foreground">{hint}</div>}
    </div>
  );
}

const barTone = {
  primary: "bg-primary",
  protein: "bg-protein",
  carbs: "bg-carbs",
  fat: "bg-fat",
  water: "bg-water",
  muted: "bg-muted-foreground",
} as const;

export function MacroBar({
  label,
  value,
  goal,
  tone,
  unit = "g",
}: {
  label: string;
  value: number;
  goal: number;
  tone: Tone;
  unit?: string;
}) {
  const pct = goal > 0 ? Math.min(100, (value / goal) * 100) : 0;
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between text-sm">
        <span className="flex items-center gap-2 font-medium">
          <span className={cn("size-2.5 rounded-full", barTone[tone])} />
          {label}
        </span>
        <span className="text-muted-foreground">
          <span className="font-semibold text-foreground">{Math.round(value)}</span> / {goal}
          {unit}
        </span>
      </div>
      <div className="h-2.5 overflow-hidden rounded-full bg-muted">
        <div
          className={cn("h-full rounded-full transition-all duration-700 ease-out", barTone[tone])}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

export function ProgressRing({
  value,
  max,
  size = 180,
  stroke = 14,
  colorVar = "--primary",
  trackVar = "--muted",
  children,
}: {
  value: number;
  max: number;
  size?: number;
  stroke?: number;
  colorVar?: string;
  trackVar?: string;
  children?: ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const pct = max > 0 ? Math.min(1, value / max) : 0;
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke} style={{ stroke: `var(${trackVar})` }} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - pct)}
          style={{ stroke: `var(${colorVar})`, transition: "stroke-dashoffset 0.8s ease" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">{children}</div>
    </div>
  );
}

export function EmptyState({ icon: Icon, title, text, action }: { icon: LucideIcon; title: string; text: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed bg-muted/40 px-6 py-10 text-center">
      <IconTile icon={Icon} tone="muted" />
      <p className="mt-3 font-display font-medium">{title}</p>
      <p className="mt-1 max-w-xs text-sm text-muted-foreground">{text}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export const chartTooltipStyle = {
  contentStyle: {
    borderRadius: 12,
    border: "1px solid var(--border)",
    boxShadow: "var(--shadow-card)",
    background: "var(--card)",
    fontSize: 12,
  },
  labelStyle: { fontWeight: 600, color: "var(--foreground)" },
};
