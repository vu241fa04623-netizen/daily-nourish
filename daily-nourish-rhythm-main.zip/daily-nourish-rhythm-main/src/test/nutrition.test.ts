import { describe, expect, it } from "vitest";
import { bmiCategory, calcBmi, healthyWeightRange, sumEntries, weekStart, type LogEntry } from "@/lib/nutrition";

describe("BMI rules", () => {
  it("computes BMI as kg / m² rounded to one decimal", () => {
    expect(calcBmi(175, 70)).toBe(22.9);
  });

  it("classifies BMI with standard WHO cut-offs", () => {
    expect(bmiCategory(18.4)).toBe("Underweight");
    expect(bmiCategory(18.5)).toBe("Normal");
    expect(bmiCategory(24.9)).toBe("Normal");
    expect(bmiCategory(25)).toBe("Overweight");
    expect(bmiCategory(30)).toBe("Obese");
  });

  it("gives the healthy weight range for BMI 18.5–24.9", () => {
    expect(healthyWeightRange(180)).toEqual([59.9, 80.7]);
  });
});

describe("calorie totals", () => {
  it("multiplies each entry's nutrients by its servings", () => {
    const base = { name: "x", emoji: "", meal: "lunch" as const, time: "" };
    const entries: LogEntry[] = [
      { ...base, id: "1", calories: 100, protein: 10, carbs: 5, fat: 2, servings: 2 },
      { ...base, id: "2", calories: 50, protein: 1, carbs: 10, fat: 0, servings: 1.5 },
    ];
    expect(sumEntries(entries)).toEqual({ calories: 275, protein: 21.5, carbs: 25, fat: 4 });
  });
});

describe("weekly reports", () => {
  it("weeks start on Monday", () => {
    expect(weekStart("2026-11-12")).toBe("2026-11-09"); // Thursday -> Monday
    expect(weekStart("2026-11-15")).toBe("2026-11-09"); // Sunday -> Monday
  });
});
